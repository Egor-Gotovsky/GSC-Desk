#!/bin/zsh
cd -- "$(dirname -- "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo 'Нужен Python 3.9 или новее: https://www.python.org/downloads/'
  read -r '?Нажмите Enter для выхода'
  exit 1
fi
python3 app.py
