"""Hourly reports and portfolio analysis. All persistence uses the local application DB."""
import json
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone


class Insights:
    def __init__(self, env):
        self.e = env
        self.lock = threading.Lock()
        self.job = {'running': False, 'done': 0, 'total': 0, 'errors': []}

    def init(self):
        with self.e['db']() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS hourly_reports(site TEXT,type TEXT,window_end TEXT,payload TEXT,updated TEXT,
                PRIMARY KEY(site,type));
            CREATE TABLE IF NOT EXISTS opportunities(site TEXT PRIMARY KEY,payload TEXT,updated TEXT);
            CREATE TABLE IF NOT EXISTS alert_states(id TEXT PRIMARY KEY,acknowledged INTEGER DEFAULT 0);
            ''')

    def window(self):
        end = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
        return end - timedelta(hours=24), end

    def hour_time(self, value):
        result = datetime.fromisoformat(value.replace('Z', '+00:00'))
        return result if result.tzinfo else result.replace(tzinfo=self.e['PT'])

    def hourly_query(self, site, kind, dimension=None, filters=None, window=None):
        start, end = window or self.window()
        body = {'startDate': str(start.astimezone(self.e['PT']).date()),
                'endDate': str((end - timedelta(seconds=1)).astimezone(self.e['PT']).date()),
                'type': kind, 'dataState': 'hourly_all', 'dimensions': ['hour'] + ([dimension] if dimension else []),
                'rowLimit': 25000}
        if filters:
            body['dimensionFilterGroups'] = [{'filters': filters}]
        rows, metadata, truncated = [], {}, False
        for offset in (0, 25000):
            response = self.e['query'](site, dict(body, startRow=offset))
            part = response.get('rows', [])
            metadata.update(response.get('metadata', {}))
            rows.extend(r for r in part if start <= self.hour_time(r['keys'][0]) < end)
            if len(part) < 25000:
                break
            if offset == 25000:
                truncated = True
        rows.sort(key=lambda r: self.hour_time(r['keys'][0]))
        return {'rows': rows, 'metadata': metadata, 'truncated': truncated,
                'window_start': start.isoformat(), 'window_end': end.isoformat(), 'period': '24h'}

    def fetch_hour_report(self, site, kind, window=None):
        result = self.hourly_query(site, kind, window=window)
        result['totals'] = self.e['total_rows'](result['rows'])
        with self.e['db']() as c:
            c.execute('INSERT OR REPLACE INTO hourly_reports VALUES(?,?,?,?,?)',
                      (site, kind, result['window_end'], json.dumps(result), self.e['now']()))
            c.execute('UPDATE sites SET last_sync=?,error=NULL WHERE id=?', (self.e['now'](), site))
        return result

    def hourly_dashboard(self, kind):
        _, end = self.window()
        with self.e['db']() as c:
            cached = {r['site']: r for r in c.execute('SELECT * FROM hourly_reports WHERE type=? AND window_end=?', (kind, end.isoformat()))}
            sites = [dict(r) for r in c.execute('SELECT * FROM sites ORDER BY id')]
        for site in sites:
            row = cached.get(site['id'])
            site.update(report=json.loads(row['payload']) if row else None, report_updated=row['updated'] if row else None)
        return {'sites': sites, 'period': '24h', 'window_end': end.isoformat()}

    def hourly_detail(self, site, kind, dimension, filters, offset):
        window = self.window()
        summary = self.hourly_query(site, kind, filters=filters, window=window)
        table = self.hourly_query(site, kind, dimension, filters, window)
        grouped = {}
        for row in table['rows']:
            grouped.setdefault(row['keys'][1], []).append(row)
        rows = [dict(self.e['total_rows'](items), keys=[label]) for label, items in grouped.items()]
        rows.sort(key=lambda r: (-r['clicks'], r['keys'][0]))
        return dict(summary, series=summary['rows'], rows=rows[offset:offset + 50],
                    totals=self.e['total_rows'](summary['rows']), offset=offset, has_more=len(rows) > offset + 50,
                    truncated=table['truncated'], updated=self.e['now']())

    def history(self, site, end):
        """Calendar coverage includes zero-result days, but not incomplete dates."""
        with self.e['db']() as c:
            reports = c.execute("SELECT * FROM reports WHERE site=? AND type='web' ORDER BY updated", (site,)).fetchall()
        days = {}
        for report in reports:
            payload = json.loads(report['payload'])
            incomplete = payload.get('metadata', {}).get('first_incomplete_date')
            first = datetime.fromisoformat(report['start']).date()
            last = min(datetime.fromisoformat(report['end']).date(), end)
            indexed = {r['keys'][0]: r for r in payload.get('rows', [])}
            while first <= last:
                key = str(first)
                if incomplete and key >= incomplete:
                    days.pop(key, None)
                else:
                    days[key] = indexed.get(key, {'clicks': 0, 'impressions': 0, 'position': 0, 'ctr': 0})
                first += timedelta(days=1)
        return days

    def alerts(self):
        settings = self.e['setting']('alert_settings', {'drop': 30, 'min_clicks': 20, 'min_impressions': 100, 'position': 3, 'stale_hours': 36})
        end = datetime.now(self.e['PT']).date() - timedelta(days=3)
        start = end - timedelta(days=20)
        output, insufficient = [], []
        with self.e['db']() as c:
            sites = [dict(r) for r in c.execute('SELECT * FROM sites WHERE active=1')]
            acknowledged = {r['id'] for r in c.execute('SELECT id FROM alert_states WHERE acknowledged=1')}
        for site in sites:
            def add(kind, title, message, severity='warning', value=0):
                ident = site['id'] + '|' + kind + '|' + str(end)
                output.append({'id': ident, 'site': site['id'], 'tag': site['tag'], 'kind': kind, 'title': title,
                               'message': message, 'severity': severity, 'value': value, 'acknowledged': ident in acknowledged})
            if site['error']:
                add('sync_error', 'Ошибка синхронизации', site['error'], 'critical')
            age = float('inf') if not site['last_sync'] else (datetime.now(timezone.utc) - datetime.fromisoformat(site['last_sync'])).total_seconds() / 3600
            if age > settings['stale_hours']:
                add('stale', 'Давно не обновлялся', 'Нет успешной загрузки более %s ч.' % settings['stale_hours'])
            days = self.history(site['id'], end)
            keys = [str(start + timedelta(days=i)) for i in range(21)]
            if not all(k in days for k in keys):
                insufficient.append(site['id'])
                continue
            baseline = self.e['total_rows']([days[k] for k in keys[:14]])
            recent = self.e['total_rows']([days[k] for k in keys[14:]])
            for metric, minimum, title in [('clicks', settings['min_clicks'], 'Падение кликов'), ('impressions', settings['min_impressions'], 'Падение показов')]:
                expected = baseline[metric] / 2
                if expected >= minimum:
                    drop = (1 - recent[metric] / expected) * 100
                    if drop >= settings['drop']:
                        add(metric + '_drop', title, 'За 7 дней: %s; обычный недельный уровень: %.1f; падение %.1f%%.' % (recent[metric], expected, drop), 'critical' if drop >= 60 else 'warning', drop)
            if recent['impressions'] == 0 and baseline['impressions'] >= settings['min_impressions'] * 2:
                add('no_impressions', 'Нет показов', 'Ноль показов за 7 полных дней при наличии показов в предыдущие 14 дней.', 'critical', 100)
            delta = recent['position'] - baseline['position']
            if recent['impressions'] >= settings['min_impressions'] and baseline['impressions'] >= settings['min_impressions'] * 2 and delta >= settings['position']:
                add('position_drop', 'Ухудшение средней позиции', 'Было %.1f → стало %.1f (хуже на %.1f).' % (baseline['position'], recent['position'], delta), value=delta)
        output.sort(key=lambda a: (a['severity'] != 'critical', -a['value'], a['site']))
        return {'alerts': output, 'insufficient': insufficient, 'settings': settings, 'start': str(start), 'end': str(end),
                'updated': self.e['now'](), 'total_sites': len(sites)}

    def set_alert_settings(self, params):
        limits = {'drop': (5, 100), 'min_clicks': (1, 1000000), 'min_impressions': (1, 10000000), 'position': (0.5, 100), 'stale_hours': (1, 720)}
        values = {}
        for name, (low, high) in limits.items():
            value = float(params[name])
            if not low <= value <= high:
                raise ValueError('Некорректный порог: ' + name)
            values[name] = value
        self.e['save_setting']('alert_settings', values)
        return {'ok': True}

    def fetch_rows(self, site, start, end, dimension):
        rows = []
        for offset in (0, 25000):
            result = self.e['query'](site, {'startDate': str(start), 'endDate': str(end), 'type': 'web',
                'dataState': 'final', 'dimensions': [dimension], 'rowLimit': 25000, 'startRow': offset})
            part = result.get('rows', [])
            rows.extend(part)
            if len(part) < 25000:
                return rows, False
        return rows, True

    def scan_site(self, site, start, end):
        queries, tq = self.fetch_rows(site, start, end, 'query')
        pages, tp = self.fetch_rows(site, start, end, 'page')
        previous, tb = self.fetch_rows(site, start - timedelta(days=28), start - timedelta(days=1), 'page')
        current = {r['keys'][0]: r for r in pages}
        losing = []
        for before in previous:
            after = current.get(before['keys'][0])
            # Missing rows are not evidence of zero traffic: privacy and API limits apply.
            if after and before['clicks'] >= 10 and before['clicks'] > after['clicks']:
                losing.append({'label': before['keys'][0], 'before': before['clicks'], 'after': after['clicks'],
                               'loss': before['clicks'] - after['clicks'], 'drop': (1 - after['clicks'] / before['clicks']) * 100})
        payload = {'queries': [dict(r, label=r['keys'][0]) for r in queries if 4 <= r.get('position', 0) <= 15],
                   'pages': losing, 'start': str(start), 'end': str(end), 'truncated': tq or tp or tb}
        with self.e['db']() as c:
            c.execute('INSERT OR REPLACE INTO opportunities VALUES(?,?,?)', (site, json.dumps(payload), self.e['now']()))

    def start_opportunities(self):
        account = self.e['ACCOUNTS'].current()
        if not self.e['read_private']('tokens.json'):
            raise ValueError('Подключите Google для анализа возможностей.')
        if not self.lock.acquire(blocking=False):
            return {'started': False}
        with self.e['db']() as c:
            sites = [r[0] for r in c.execute('SELECT id FROM sites WHERE active=1')]
        self.job = {'running': True, 'done': 0, 'total': len(sites), 'errors': []}
        def work():
            end = datetime.now(self.e['PT']).date() - timedelta(days=3)
            start = end - timedelta(days=27)
            try:
                def perform(site):
                    try:
                        self.scan_site(site, start, end)
                    except Exception as exc:
                        self.job['errors'].append({'site': site, 'message': str(exc)})
                    finally:
                        self.job['done'] += 1
                with ThreadPoolExecutor(max_workers=2) as pool:
                    list(pool.map(lambda site: self.e['ACCOUNTS'].run(account, perform, site), sites))
            finally:
                self.job['running'] = False
                self.e['save_setting']('opportunity_job', self.job)
                self.lock.release()
        threading.Thread(target=self.e['ACCOUNTS'].run, args=(account, work), daemon=True).start()
        return {'started': True}

    def opportunities(self):
        with self.e['db']() as c:
            records = [dict(r) for r in c.execute('SELECT o.*,s.tag FROM opportunities o JOIN sites s ON o.site=s.id WHERE s.active=1')]
        return {'sites': [dict(site=r['site'], tag=r['tag'], updated=r['updated'], **json.loads(r['payload'])) for r in records],
                'job': self.job if self.job['running'] or self.job['total'] else self.e['setting']('opportunity_job', self.job)}
