"""Collections, imported GSC coverage and first-impression observations."""
import calendar
import csv
import io
import json
import re
import secrets
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta


class Portfolio:
    def __init__(self, env):
        self.e = env
        self.lock = threading.Lock()
        self.job = {'running': False, 'done': 0, 'total': 0, 'errors': []}

    def init(self):
        with self.e['db']() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS collections(id TEXT PRIMARY KEY,kind TEXT NOT NULL,name TEXT NOT NULL,color TEXT NOT NULL,
                UNIQUE(kind,name));
            CREATE TABLE IF NOT EXISTS site_collections(site TEXT,collection_id TEXT,PRIMARY KEY(site,collection_id));
            CREATE TABLE IF NOT EXISTS site_observation(site TEXT PRIMARY KEY,started TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS impression_days(site TEXT,day TEXT,impressions REAL,PRIMARY KEY(site,day));
            CREATE TABLE IF NOT EXISTS hook_scans(site TEXT PRIMARY KEY,start TEXT,end TEXT,updated TEXT);
            CREATE TABLE IF NOT EXISTS hook_queries(site TEXT PRIMARY KEY,day TEXT,payload TEXT,updated TEXT);
            CREATE TABLE IF NOT EXISTS indexing_reports(site TEXT,day TEXT,indexed INTEGER,not_indexed INTEGER,source TEXT,updated TEXT,
                PRIMARY KEY(site,day));
            ''')
            migrated = c.execute("SELECT 1 FROM settings WHERE key='collections_v1'").fetchone()
            if not migrated:
                for row in c.execute("SELECT id,tag FROM sites WHERE tag<>''").fetchall():
                    name = row['tag']
                    existing = c.execute("SELECT id FROM collections WHERE kind='group' AND name=?", (name,)).fetchone()
                    ident = existing[0] if existing else secrets.token_hex(12)
                    c.execute('INSERT OR IGNORE INTO collections VALUES(?,?,?,?)', (ident, 'group', name, '#4285f4'))
                    c.execute('INSERT OR IGNORE INTO site_collections VALUES(?,?)', (row['id'], ident))
                c.execute("INSERT INTO settings VALUES('collections_v1','true')")
            c.execute('INSERT OR IGNORE INTO site_observation SELECT id,? FROM sites', (self.e['now'](),))

    def collections(self):
        with self.e['db']() as c:
            groups = [dict(r) for r in c.execute('SELECT * FROM collections ORDER BY kind,name')]
            for group in groups:
                group['sites'] = [r[0] for r in c.execute('SELECT site FROM site_collections WHERE collection_id=?', (group['id'],))]
        return {'collections': groups}

    def enrich(self, data):
        collections = self.collections()['collections']
        by_site = {}
        for item in collections:
            for site in item['sites']:
                by_site.setdefault(site, []).append({k: item[k] for k in ('id', 'kind', 'name', 'color')})
        for site in data['sites']:
            items = by_site.get(site['id'], [])
            site['groups'] = [i for i in items if i['kind'] == 'group']
            site['labels'] = [i for i in items if i['kind'] == 'tag']
        data['collections'] = collections
        return data

    def validate_sites(self, c, selected):
        if not isinstance(selected, list) or len(selected) > 10000 or not all(isinstance(s, str) for s in selected):
            raise ValueError('Некорректный список сайтов')
        known = {r[0] for r in c.execute('SELECT id FROM sites')}
        if not set(selected) <= known:
            raise ValueError('Сайт не найден в этом аккаунте')

    def legacy_groups(self, c):
        # Keep old report/export consumers compatible. Never use this string for membership.
        for row in c.execute('SELECT id FROM sites').fetchall():
            names = [r[0] for r in c.execute("SELECT name FROM collections JOIN site_collections ON id=collection_id WHERE site=? AND kind='group' ORDER BY name", (row['id'],))]
            c.execute('UPDATE sites SET tag=? WHERE id=?', (', '.join(names), row['id']))

    def save_collection(self, params):
        name, kind = str(params.get('name', '')).strip(), params.get('kind')
        color = params.get('color', '#4285f4')
        if not name or len(name) > 80 or kind not in ('group', 'tag') or not re.fullmatch(r'#[0-9a-fA-F]{6}', str(color)):
            raise ValueError('Введите название до 80 символов и выберите цвет')
        ident = params.get('id') or secrets.token_hex(12)
        selected = list(dict.fromkeys(params.get('sites', [])))
        with self.e['db']() as c:
            self.validate_sites(c, selected)
            existing = c.execute('SELECT * FROM collections WHERE id=?', (ident,)).fetchone()
            duplicate = c.execute('SELECT id FROM collections WHERE name=? AND kind=? AND id<>?', (name, kind, ident)).fetchone()
            if duplicate:
                raise ValueError('Такое название уже есть. Выберите его в меню редактирования.')
            if params.get('id') and (not existing or existing['kind'] != kind):
                raise ValueError('Группа или тег не найдены')
            c.execute('INSERT OR REPLACE INTO collections VALUES(?,?,?,?)', (ident, kind, name, color.lower()))
            c.execute('DELETE FROM site_collections WHERE collection_id=?', (ident,))
            c.executemany('INSERT INTO site_collections VALUES(?,?)', [(s, ident) for s in selected])
            self.legacy_groups(c)
        return dict(self.collections(), id=ident)

    def save_site(self, params):
        site = params.get('site')
        with self.e['db']() as c:
            self.validate_sites(c, [site])
            if 'favorite' in params:
                c.execute('UPDATE sites SET favorite=? WHERE id=?', (int(bool(params['favorite'])), site))
            for field, kind in [('groups', 'group'), ('labels', 'tag')]:
                if field not in params:
                    continue
                selected = params[field]
                if not isinstance(selected, list) or not all(isinstance(i, str) for i in selected):
                    raise ValueError('Некорректный список групп или тегов')
                valid = {r[0] for r in c.execute('SELECT id FROM collections WHERE kind=?', (kind,))}
                if not set(selected) <= valid:
                    raise ValueError('Группа или тег не найдены в этом аккаунте')
                c.execute('DELETE FROM site_collections WHERE site=? AND collection_id IN (SELECT id FROM collections WHERE kind=?)', (site, kind))
                c.executemany('INSERT INTO site_collections VALUES(?,?)', [(site, i) for i in set(selected)])
            self.legacy_groups(c)
        return {'ok': True}

    def import_indexing(self, params):
        site = params.get('site')
        text = str(params.get('csv', '')).lstrip('\ufeff')
        if len(text) > 1500000:
            raise ValueError('CSV слишком большой')
        try:
            dialect = csv.Sniffer().sniff(text[:8192], delimiters=',;\t')
            reader = csv.DictReader(io.StringIO(text), dialect=dialect)
        except csv.Error:
            raise ValueError('Не удалось прочитать CSV. Нужна таблица графика индексации из GSC.')
        def norm(value):
            return re.sub(r'[^a-zа-яё]', '', str(value).lower())
        names = {norm(h): h for h in reader.fieldnames or []}
        def find(aliases):
            return next((names[a] for a in aliases if a in names), None)
        day_col = find(['date', 'дата'])
        indexed_col = find(['indexed', 'indexedpages', 'проиндексировано', 'проиндексированные', 'проиндексированныестраницы', 'вовсехиндексах'])
        excluded_col = find(['notindexed', 'notindexedpages', 'непроиндексировано', 'непроиндексированные', 'непроиндексированныестраницы'])
        # Explicit mapping supports localized Google exports without guessing columns.
        mapping = params.get('columns', {})
        day_col = mapping.get('date') or day_col
        indexed_col = mapping.get('indexed') or indexed_col
        excluded_col = mapping.get('not_indexed') or excluded_col
        if not all(x and x in (reader.fieldnames or []) for x in (day_col, indexed_col, excluded_col)) or len({day_col,indexed_col,excluded_col}) != 3:
            raise ValueError('Выберите три разных столбца: дата, проиндексировано, не проиндексировано.')
        rows = []
        for row in reader:
            if not any(row.values()):
                continue
            raw_day = row.get(day_col, '').strip()
            parsed = None
            for fmt in ('%Y-%m-%d', '%d.%m.%Y', '%m/%d/%Y'):
                try:
                    parsed = datetime.strptime(raw_day, fmt).date()
                    break
                except ValueError:
                    pass
            if not parsed or parsed > datetime.now(self.e['PT']).date():
                raise ValueError('Некорректная или будущая дата: ' + raw_day)
            def count(column):
                raw = re.sub(r'[\s\u00a0\u202f,]', '', row.get(column, ''))
                if not re.fullmatch(r'\d+', raw):
                    raise ValueError('В числовых столбцах должны быть целые неотрицательные числа')
                number = int(raw)
                if number > 10**12:
                    raise ValueError('Слишком большое число страниц')
                return number
            rows.append((site, str(parsed), count(indexed_col), count(excluded_col), 'GSC CSV', self.e['now']()))
        if not rows:
            raise ValueError('В CSV нет строк данных')
        with self.e['db']() as c:
            self.validate_sites(c, [site])
            c.executemany('INSERT OR REPLACE INTO indexing_reports VALUES(?,?,?,?,?,?)', rows)
        return {'ok': True, 'rows': len(rows)}

    def indexing(self):
        with self.e['db']() as c:
            rows = [dict(r) for r in c.execute('''SELECT s.id AS site,i.day,i.indexed,i.not_indexed,i.source,i.updated FROM sites s
                LEFT JOIN indexing_reports i ON s.id=i.site AND i.day=(SELECT MAX(day) FROM indexing_reports WHERE site=s.id)
                WHERE s.active=1 ORDER BY s.id''')]
        return {'sites': rows}

    def observe(self, site, start, end, payload):
        cutoff = datetime.now(self.e['PT']).date() - timedelta(days=3)
        incomplete = payload.get('metadata', {}).get('first_incomplete_date')
        if incomplete:
            cutoff = min(cutoff, date.fromisoformat(incomplete) - timedelta(days=1))
        first, last = date.fromisoformat(start), min(date.fromisoformat(end), cutoff)
        indexed = {r['keys'][0]: r.get('impressions', 0) for r in payload.get('rows', [])}
        with self.e['db']() as c:
            c.execute('INSERT OR IGNORE INTO site_observation VALUES(?,?)', (site, self.e['now']()))
            while first <= last:
                c.execute('INSERT OR REPLACE INTO impression_days VALUES(?,?,?)', (site, str(first), indexed.get(str(first), 0)))
                first += timedelta(days=1)
            positive = c.execute('SELECT day FROM impression_days WHERE site=? AND impressions>0 ORDER BY day LIMIT 1', (site,)).fetchone()
            cached = c.execute('SELECT day FROM hook_queries WHERE site=?', (site,)).fetchone()
        if positive and (not cached or cached['day'] != positive['day']):
            self.fetch_hook_queries(site, positive['day'])

    def fetch_hook_queries(self, site, day):
        try:
            rows, limited = [], False
            for offset in (0, 25000):
                result = self.e['query'](site, {'startDate': day, 'endDate': day, 'type': 'web', 'dataState': 'final',
                    'dimensions': ['query'], 'rowLimit': 25000, 'startRow': offset})
                part = result.get('rows', [])
                rows.extend(r for r in part if r.get('impressions', 0) > 0)
                if len(part) < 25000:
                    break
                limited = offset == 25000
            payload = {'rows': rows, 'truncated': limited}
        except Exception as exc:
            # Do not turn a successful daily sync into a failure because detail is unavailable.
            payload = {'rows': [], 'error': str(exc)}
        with self.e['db']() as c:
            c.execute('INSERT OR REPLACE INTO hook_queries VALUES(?,?,?,?)', (site, day, json.dumps(payload), self.e['now']()))

    def scan_site(self, site):
        today = datetime.now(self.e['PT']).date()
        month_index = today.year * 12 + today.month - 1 - 16
        year, month = divmod(month_index, 12)
        start = date(year, month + 1, min(today.day, calendar.monthrange(year, month + 1)[1]))
        end = today - timedelta(days=3)
        result = self.e['query'](site, {'startDate': str(start), 'endDate': str(end), 'type': 'web',
                                      'dataState': 'final', 'dimensions': ['date'], 'rowLimit': 25000})
        self.observe(site, str(start), str(end), result)
        with self.e['db']() as c:
            c.execute('INSERT OR REPLACE INTO hook_scans VALUES(?,?,?,?)', (site, str(start), str(end), self.e['now']()))
            cached = c.execute('SELECT day,payload FROM hook_queries WHERE site=?', (site,)).fetchone()
        if cached and json.loads(cached['payload']).get('error'):
            self.fetch_hook_queries(site, cached['day'])

    def start_scan(self):
        if not self.e['read_private']('tokens.json'):
            raise ValueError('Подключите Google для загрузки истории')
        if not self.lock.acquire(blocking=False):
            return {'started': False}
        account = self.e['ACCOUNTS'].current()
        with self.e['db']() as c:
            sites = [r[0] for r in c.execute('SELECT id FROM sites WHERE active=1')]
        self.job = {'running': True, 'done': 0, 'total': len(sites), 'errors': []}
        def work():
            def perform(site):
                try:
                    self.scan_site(site)
                except Exception as exc:
                    with self.e['LOCK']:
                        self.job['errors'].append({'site': site, 'message': str(exc)})
                finally:
                    with self.e['LOCK']:
                        self.job['done'] += 1
            try:
                with ThreadPoolExecutor(max_workers=2) as pool:
                    list(pool.map(lambda s: self.e['ACCOUNTS'].run(account, perform, s), sites))
            finally:
                self.job['running'] = False
                self.e['save_setting']('hooks_job', self.job)
                self.lock.release()
        threading.Thread(target=self.e['ACCOUNTS'].run, args=(account, work), daemon=True).start()
        return {'started': True}

    def hooks(self):
        output = []
        with self.e['db']() as c:
            sites = c.execute('SELECT s.id,o.started FROM sites s JOIN site_observation o ON s.id=o.site WHERE s.active=1').fetchall()
            for site in sites:
                first = c.execute('SELECT day,impressions FROM impression_days WHERE site=? AND impressions>0 ORDER BY day LIMIT 1', (site['id'],)).fetchone()
                if not first:
                    continue
                began = str(datetime.fromisoformat(site['started']).astimezone(self.e['PT']).date())
                earlier = c.execute('SELECT COUNT(*) FROM impression_days WHERE site=? AND day>=? AND day<? AND impressions=0', (site['id'], began, first['day'])).fetchone()[0]
                gap = (date.fromisoformat(first['day']) - date.fromisoformat(began)).days
                confirmed = gap > 0 and earlier == gap
                scan = c.execute('SELECT * FROM hook_scans WHERE site=?', (site['id'],)).fetchone()
                cached = c.execute('SELECT * FROM hook_queries WHERE site=? AND day=?', (site['id'], first['day'])).fetchone()
                output.append({'site': site['id'], 'first_day': first['day'], 'impressions': first['impressions'], 'confirmed': confirmed,
                    'observed_since': began, 'history_start': scan['start'] if scan else None, 'updated': scan['updated'] if scan else None,
                    'queries': json.loads(cached['payload']) if cached else {'rows': [], 'error': 'Запросы ещё не загружены'}})
        output.sort(key=lambda r: r['first_day'], reverse=True)
        return {'sites': output, 'job': self.job if self.job['running'] or self.job['total'] else self.e['setting']('hooks_job', self.job)}
