"""Account-local storage and execution context, including background workers."""
import json
import os
import re
import threading
from collections.abc import MutableMapping
from contextlib import contextmanager


class Accounts:
    def __init__(self, env):
        self.e = env
        self.local = threading.local()
        self.lock = threading.RLock()

    def current(self):
        return getattr(self.local, 'account', 'default')

    def key(self):
        return str(self.e['DATA']), self.current()

    def path(self, account=None):
        account = account or self.current()
        if not re.fullmatch(r'default|[a-f0-9]{32}', account):
            raise ValueError('Некорректный аккаунт')
        return self.e['DATA'] if account == 'default' else self.e['DATA'] / 'accounts' / account

    def records(self):
        p = self.e['DATA'] / 'accounts.json'
        with self.lock:
            return json.loads(p.read_text()) if p.exists() else [{'id': 'default', 'label': 'Основной аккаунт'}]

    def save_record(self, record):
        with self.lock:
            rows = self.records()
            old = next((r for r in rows if r['id'] == record['id']), None)
            if old:
                old.update(record)
            else:
                rows.append(record)
            p = self.e['DATA'] / 'accounts.json'
            temp = p.with_suffix('.tmp')
            fd = os.open(str(temp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, 'w') as f:
                json.dump(rows, f)
            os.replace(temp, p)

    def public(self):
        return {'current': self.current(), 'accounts': [
            {'id': r['id'], 'label': r['label'], 'connected': (self.path(r['id']) / 'tokens.json').exists()}
            for r in self.records()]}

    @contextmanager
    def bind(self, account, validate=False):
        self.path(account)
        if validate and not any(r['id'] == account for r in self.records()):
            raise ValueError('Аккаунт не найден. Выберите другой аккаунт.')
        previous = self.current()
        self.local.account = account
        try:
            yield
        finally:
            self.local.account = previous

    def run(self, account, fn, *args, **kwargs):
        with self.bind(account):
            return fn(*args, **kwargs)


class AccountMap(MutableMapping):
    def __init__(self, accounts):
        self.accounts, self.values = accounts, {}

    def data(self):
        return self.values.setdefault(self.accounts.key(), {'running': False, 'done': 0, 'total': 0, 'errors': []})

    def __getitem__(self, key): return self.data()[key]
    def __setitem__(self, key, value): self.data()[key] = value
    def __delitem__(self, key): del self.data()[key]
    def __iter__(self): return iter(self.data())
    def __len__(self): return len(self.data())


class AccountObject:
    def __init__(self, accounts, factory):
        object.__setattr__(self, 'accounts', accounts)
        object.__setattr__(self, 'factory', factory)
        object.__setattr__(self, 'objects', {})
        object.__setattr__(self, 'lock', threading.Lock())

    def instance(self):
        with self.lock:
            key = self.accounts.key()
            if key not in self.objects:
                self.objects[key] = self.factory()
            return self.objects[key]

    def __getattr__(self, name):
        return getattr(self.instance(), name)

    def __setattr__(self, name, value):
        setattr(self.instance(), name, value)

    def __delattr__(self, name):
        delattr(self.instance(), name)
