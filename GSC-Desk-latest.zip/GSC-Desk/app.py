#!/usr/bin/env python3
"""GSC Desk — local, dependency-free Search Console dashboard."""
import argparse
import base64
import calendar
from concurrent.futures import ThreadPoolExecutor, as_completed
import errno
import hashlib
import json
import os
import secrets
import sqlite3
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from datetime import date, datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from insights import Insights
from accounts import Accounts, AccountMap, AccountObject
from portfolio import Portfolio
DATA = Path(os.environ.get('GSC_DESK_DATA', str(ROOT / 'data')))
SCOPE = 'https://www.googleapis.com/auth/webmasters.readonly'
PT = ZoneInfo('America/Los_Angeles')
MINSK = ZoneInfo('Europe/Minsk')
LOCK = threading.RLock()
TOKEN_LOCK = threading.Lock()
JOB_LOCK = threading.Lock()
RATE_LOCK = threading.Lock()
LAST_REQUEST = 0.0
SESSIONS = set()
OAUTH = {}
ACCOUNTS = Accounts(globals())
JOB = AccountMap(ACCOUNTS)
BASE = ''
INSIGHTS = AccountObject(ACCOUNTS, lambda: Insights(globals()))
PORTFOLIO = AccountObject(ACCOUNTS, lambda: Portfolio(globals()))


def now():
    return datetime.now().astimezone().isoformat(timespec='seconds')


def db():
    c = sqlite3.connect(ACCOUNTS.path() / 'gsc.sqlite3', timeout=30)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL')
    return c


def init():
    directory = ACCOUNTS.path()
    directory.mkdir(parents=True, exist_ok=True)
    os.chmod(directory, 0o700)
    with db() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS sites(id TEXT PRIMARY KEY,permission TEXT,active INTEGER DEFAULT 1,
          favorite INTEGER DEFAULT 0,tag TEXT DEFAULT '',last_sync TEXT,error TEXT);
        CREATE TABLE IF NOT EXISTS reports(site TEXT,start TEXT,end TEXT,type TEXT,payload TEXT,updated TEXT,
          PRIMARY KEY(site,start,end,type));
        CREATE TABLE IF NOT EXISTS details(cache_key TEXT PRIMARY KEY,payload TEXT,updated REAL);
        ''')
    os.chmod(directory / 'gsc.sqlite3', 0o600)
    INSIGHTS.init()
    PORTFOLIO.init()


def setting(key, default=None):
    with db() as c:
        row = c.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
    return json.loads(row[0]) if row else default


def save_setting(key, value):
    with db() as c:
        c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)', (key, json.dumps(value)))


def read_private(name):
    p = ACCOUNTS.path() / name
    if name == 'oauth.json' and not p.exists():
        p = DATA / name
    return json.loads(p.read_text()) if p.exists() else {}


def write_private(name, value):
    p = ACCOUNTS.path() / name
    temp = p.with_suffix('.tmp')
    fd = os.open(str(temp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w') as f:
        json.dump(value, f)
    os.replace(temp, p)
    os.chmod(p, 0o600)


class APIError(Exception):
    pass


def http_json(url, body=None, headers=None, form=False):
    headers = dict(headers or {})
    data = None
    if body is not None:
        data = (urllib.parse.urlencode(body) if form else json.dumps(body)).encode()
        headers['Content-Type'] = 'application/x-www-form-urlencoded' if form else 'application/json'
    for attempt in range(4):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, data=data, headers=headers), timeout=45) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                error = json.loads(raw).get('error', {})
                reason = error.get('message', '') if isinstance(error, dict) else error
            except Exception:
                reason = ''
            if e.code in (429, 500, 502, 503, 504) and attempt < 3:
                time.sleep(min(30, 2 ** (attempt + 1)))
                continue
            if e.code == 401 or reason == 'invalid_grant':
                raise APIError('Доступ Google истёк или отозван. Подключите аккаунт заново.')
            raise APIError('Google API %s: %s' % (e.code, reason or 'Запрос не выполнен'))
        except (urllib.error.URLError, TimeoutError) as e:
            if attempt < 2:
                time.sleep(2 ** attempt)
                continue
            raise APIError('Нет ответа от Google. Проверьте интернет и повторите обновление.') from e


def access_token():
    with TOKEN_LOCK:
        token = read_private('tokens.json')
        if token.get('expires_at', 0) > time.time() + 90:
            return token['access_token']
        config = read_private('oauth.json')
        if not token.get('refresh_token'):
            raise APIError('Сначала подключите Google-аккаунт в настройках.')
        result = http_json('https://oauth2.googleapis.com/token', {
            'client_id': config['client_id'], 'client_secret': config.get('client_secret', ''),
            'refresh_token': token['refresh_token'], 'grant_type': 'refresh_token'}, form=True)
        token.update(result)
        token['expires_at'] = time.time() + result.get('expires_in', 3600)
        write_private('tokens.json', token)
        return token['access_token']


def google(path, body=None):
    global LAST_REQUEST
    token = access_token()
    with RATE_LOCK:
        delay = max(0, 0.2 - (time.monotonic() - LAST_REQUEST))
        if delay:
            time.sleep(delay)
        LAST_REQUEST = time.monotonic()
    return http_json('https://www.googleapis.com/webmasters/v3/' + path, body,
                     {'Authorization': 'Bearer ' + token})


def date_range(params):
    today = datetime.now(PT).date()
    start = date.fromisoformat(params.get('start') or str(today - timedelta(days=27)))
    end = date.fromisoformat(params.get('end') or str(today))
    month_index = today.year * 12 + today.month - 1 - 16
    year, month = divmod(month_index, 12)
    oldest = date(year, month + 1, min(today.day, calendar.monthrange(year, month + 1)[1]))
    if start > end or end > today or start < oldest:
        raise ValueError('Выберите даты в пределах последних 16 месяцев, не позднее сегодня (время GSC).')
    kind = params.get('type', 'web')
    if kind not in ('web', 'image', 'video', 'news', 'discover', 'googleNews'):
        raise ValueError('Неизвестный тип поиска')
    return str(start), str(end), kind


def query(site, body):
    return google('sites/' + urllib.parse.quote(site, safe='') + '/searchAnalytics/query', body)


def total_rows(rows):
    clicks = sum(r.get('clicks', 0) for r in rows)
    impressions = sum(r.get('impressions', 0) for r in rows)
    return {'clicks': clicks, 'impressions': impressions,
            'ctr': clicks / impressions if impressions else 0,
            'position': sum(r.get('position', 0) * r.get('impressions', 0) for r in rows) / impressions if impressions else 0}


def fetch_report(site, start, end, kind):
    # Reuse completed historical days across overlapping report ranges.
    with db() as c:
        cached = c.execute('SELECT * FROM reports WHERE site=? AND type=? ORDER BY updated', (site, kind)).fetchall()
    covered, historical = set(), {}
    cutoff = str(datetime.now(PT).date() - timedelta(days=7))
    for report in cached:
        day = date.fromisoformat(max(start, report['start']))
        stop = min(end, report['end'], cutoff)
        while str(day) <= stop:
            covered.add(str(day))
            day += timedelta(days=1)
        for row in json.loads(report['payload']).get('rows', []):
            historical[row['keys'][0]] = row
    missing = []
    day = date.fromisoformat(start)
    while str(day) <= end:
        if str(day) not in covered:
            missing.append(str(day))
        day += timedelta(days=1)
    fetch_start = missing[0] if missing else start
    body = {'startDate': fetch_start, 'endDate': end, 'type': kind, 'dataState': 'all', 'dimensions': ['date'], 'rowLimit': 25000}
    result = query(site, body)
    rows = [r for d, r in historical.items() if start <= d < fetch_start]
    rows += result.get('rows', [])
    rows.sort(key=lambda r: r['keys'][0])
    payload = {'rows': rows, 'totals': total_rows(rows), 'metadata': result.get('metadata', {})}
    with db() as c:
        c.execute('INSERT OR REPLACE INTO reports VALUES(?,?,?,?,?,?)', (site, start, end, kind, json.dumps(payload), now()))
        c.execute('UPDATE sites SET last_sync=?,error=NULL WHERE id=?', (now(), site))
        # A successful manual or scheduled refresh invalidates query/page caches for this property.
        keys = c.execute('SELECT cache_key FROM details').fetchall()
        for key in keys:
            if json.loads(key[0])[0] == site:
                c.execute('DELETE FROM details WHERE cache_key=?', (key[0],))
    if kind == 'web':
        PORTFOLIO.observe(site, start, end, payload)


def discover():
    result = google('sites')
    sites = [s for s in result.get('siteEntry', []) if s.get('permissionLevel') != 'siteUnverifiedUser']
    with db() as c:
        c.execute('UPDATE sites SET active=0')
        for site in sites:
            c.execute('INSERT INTO sites(id,permission,active) VALUES(?,?,1) ON CONFLICT(id) DO UPDATE SET permission=excluded.permission,active=1',
                      (site['siteUrl'], site.get('permissionLevel', '')))
            c.execute('INSERT OR IGNORE INTO site_observation(site,started) VALUES(?,?)', (site['siteUrl'], now()))
    return [s['siteUrl'] for s in sites]


def sync_worker(start, end, kind, site, slot, period='daily'):
    account = ACCOUNTS.current()
    try:
        sites = [site] if site else discover()
        ranges = [(start, end, kind)]
        watched = setting('watched_range') if slot and period != '24h' else None
        if watched:
            try:
                extra = date_range(watched)
                if extra not in ranges:
                    ranges.append(extra)
            except ValueError:
                pass
        tasks = [(item, bounds) for item in sites for bounds in ranges]
        hour_window = INSIGHTS.window()
        with LOCK:
            JOB.update(total=len(tasks), message='Загружаем статистику')
        def perform(task):
            item, bounds = task
            with LOCK:
                JOB['current'] = item
            try:
                if period == '24h':
                    INSIGHTS.fetch_hour_report(item, kind, hour_window)
                else:
                    fetch_report(item, *bounds)
            except Exception as e:
                message = str(e) if isinstance(e, APIError) else 'Ошибка загрузки. Повторите запрос.'
                with db() as c:
                    c.execute('UPDATE sites SET error=? WHERE id=?', (message, item))
                with LOCK:
                    JOB['errors'].append({'site': item, 'message': message})
            finally:
                with LOCK:
                    JOB['done'] += 1
        with ThreadPoolExecutor(max_workers=6) as executor:
            list(executor.map(lambda task: ACCOUNTS.run(account, perform, task), tasks))
        if not JOB['errors']:
            save_setting('last_full_sync' if not site else 'last_site_sync', now())
        if slot:
            save_setting('last_slot', slot)
    except Exception as e:
        with LOCK:
            JOB['errors'].append({'site': '', 'message': str(e) if isinstance(e, APIError) else 'Не удалось получить список сайтов.'})
        if slot:
            # Persist attempt to avoid retrying hundreds of requests every scheduler tick.
            save_setting('last_slot', slot)
    finally:
        with LOCK:
            JOB.update(running=False, finished=now(), message='Завершено с ошибками' if JOB['errors'] else 'Данные обновлены')
        save_setting('last_job', dict(JOB))
        JOB_LOCK.release()


def start_sync(params, slot=None):
    start, end, kind = date_range(params)
    period = params.get('period', 'daily')
    if period not in ('daily', '24h'):
        raise ValueError('Неизвестный период')
    site = params.get('site')
    if site:
        with db() as c:
            if not c.execute('SELECT 1 FROM sites WHERE id=? AND active=1', (site,)).fetchone():
                raise ValueError('Сайт не найден среди доступных ресурсов')
    if not read_private('tokens.json'):
        raise ValueError('Подключите Google в настройках.')
    if not JOB_LOCK.acquire(blocking=False):
        return {'started': False, 'job': dict(JOB)}
    if not site and not slot and period == 'daily':
        save_setting('watched_range', {'start': start, 'end': end, 'type': kind})
    with LOCK:
        JOB.clear()
        JOB.update(running=True, done=0, total=1 if site else 0, errors=[], started=now(), message='Получаем список сайтов', start=start, end=end, type=kind)
    threading.Thread(target=ACCOUNTS.run, args=(ACCOUNTS.current(), sync_worker, start, end, kind, site, slot, period), daemon=True).start()
    return {'started': True, 'job': dict(JOB)}


def due_slot(dt):
    dt = dt.astimezone(MINSK)
    return dt.replace(hour=17 if dt.hour >= 17 else 0, minute=0, second=0, microsecond=0).isoformat()


def scheduler():
    while True:
        try:
            for account in ACCOUNTS.records():
                with ACCOUNTS.bind(account['id']):
                    if read_private('tokens.json'):
                        slot = due_slot(datetime.now(MINSK))
                        if setting('last_slot') != slot and not JOB.get('running'):
                            start_sync({}, slot=slot)
        except Exception:
            pass
        time.sleep(20)


def dashboard(params):
    start, end, kind = date_range(params)
    if params.get('period') == '24h':
        return PORTFOLIO.enrich(INSIGHTS.hourly_dashboard(kind))
    with db() as c:
        sites = c.execute('SELECT * FROM sites ORDER BY id').fetchall()
        reports = {r['site']: r for r in c.execute('SELECT * FROM reports WHERE start=? AND end=? AND type=?', (start, end, kind))}
    result = []
    for row in sites:
        item = dict(row)
        cached = reports.get(row['id'])
        item['report'] = json.loads(cached['payload']) if cached else None
        item['report_updated'] = cached['updated'] if cached else None
        result.append(item)
    return PORTFOLIO.enrich({'sites': result, 'start': start, 'end': end, 'type': kind})


def detail(params):
    start, end, kind = date_range(params)
    site = params.get('site', '')
    dimension = params.get('dimension', 'query')
    if dimension not in ('query', 'page', 'country', 'device'):
        raise ValueError('Некорректная группировка')
    with db() as c:
        if not c.execute('SELECT 1 FROM sites WHERE id=? AND active=1', (site,)).fetchone():
            raise ValueError('Нет доступа к сайту')
    filters = []
    for name in ('query', 'page', 'country', 'device'):
        value = str(params.get(name, '')).strip()
        if value:
            filters.append({'dimension': name, 'operator': 'contains' if name in ('query', 'page') else 'equals', 'expression': value})
    if kind in ('discover', 'googleNews') and (dimension == 'query' or any(f['dimension'] == 'query' for f in filters)):
        raise ValueError('Для Discover и Google News Google не предоставляет поисковые запросы. Выберите «Страницы».')
    offset = max(0, int(params.get('offset', 0)))
    if offset > 49950 or offset % 50:
        raise ValueError('Некорректная страница')
    if params.get('period') == '24h':
        return INSIGHTS.hourly_detail(site, kind, dimension, filters, offset)
    key = json.dumps([site, start, end, kind, dimension, filters, offset], ensure_ascii=False)
    with db() as c:
        cached = c.execute('SELECT * FROM details WHERE cache_key=?', (key,)).fetchone()
    if cached and time.time() - cached['updated'] < 21600 and not params.get('force'):
        return json.loads(cached['payload'])
    body = {'startDate': start, 'endDate': end, 'type': kind, 'dataState': 'all'}
    if filters:
        body['dimensionFilterGroups'] = [{'filters': filters}]
    summary = query(site, dict(body, dimensions=['date'], rowLimit=25000))
    table = query(site, dict(body, dimensions=[dimension], rowLimit=51, startRow=offset))
    rows = table.get('rows', [])
    payload = {'rows': rows[:50], 'has_more': len(rows) > 50 and offset < 49950, 'offset': offset,
               'series': sorted(summary.get('rows', []), key=lambda r: r['keys'][0]),
               'totals': total_rows(summary.get('rows', [])), 'metadata': summary.get('metadata', {}), 'updated': now()}
    with db() as c:
        c.execute('INSERT OR REPLACE INTO details VALUES(?,?,?)', (key, json.dumps(payload), time.time()))
    return payload


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # OAuth callback URLs contain codes: never log request paths.

    def valid_host(self):
        return self.headers.get('Host') == urllib.parse.urlparse(BASE).netloc

    def session(self):
        cookies = self.headers.get('Cookie', '').split(';')
        for cookie in cookies:
            if cookie.strip().startswith('gsc_session='):
                token = cookie.strip().split('=', 1)[1]
                if token in SESSIONS:
                    return token
        return None

    def send(self, value, status=200, content_type='application/json', cookie=None):
        data = json.dumps(value, ensure_ascii=False).encode() if content_type == 'application/json' else value
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        if cookie:
            self.send_header('Set-Cookie', 'gsc_session=' + cookie + '; HttpOnly; SameSite=Lax; Path=/')
        self.end_headers()
        self.wfile.write(data)

    def redirect(self, url):
        self.send_response(303)
        self.send_header('Location', url)
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.end_headers()

    def do_GET(self):
        try:
            with ACCOUNTS.bind(self.headers.get('X-GSC-Account', 'default'), validate=True):
                return self.handle_get()
        except ValueError as e:
            return self.send({'error': str(e)}, 400)

    def handle_get(self):
        if not self.valid_host():
            return self.send({'error': 'Invalid host'}, 403)
        parsed = urllib.parse.urlparse(self.path)
        params = dict(urllib.parse.parse_qsl(parsed.query))
        path = parsed.path
        try:
            if path == '/':
                token = self.session() or secrets.token_urlsafe(32)
                SESSIONS.add(token)
                return self.send((ROOT / 'static/index.html').read_bytes(), content_type='text/html; charset=utf-8', cookie=token)
            if path in ('/app.js', '/enhancements.js', '/workspace.js', '/portfolio.js', '/style.css', '/themes.css', '/workspace.css', '/portfolio.css'):
                return self.send((ROOT / 'static' / path[1:]).read_bytes(), content_type='text/javascript; charset=utf-8' if path.endswith('js') else 'text/css; charset=utf-8')
            if not self.session():
                return self.send({'error': 'Откройте приложение заново.'}, 403)
            if path == '/oauth/callback':
                state = OAUTH.pop(params.get('state', ''), None)
                if not state or state['session'] != self.session() or time.time() - state['created'] > 600:
                    raise ValueError('Авторизация устарела. Начните подключение заново.')
                if params.get('error'):
                    return self.redirect('/?auth=cancelled')
                config = state['config']
                token = http_json('https://oauth2.googleapis.com/token', {
                    'client_id': config['client_id'], 'client_secret': config.get('client_secret', ''),
                    'code': params.get('code', ''), 'code_verifier': state['verifier'],
                    'redirect_uri': BASE + '/oauth/callback', 'grant_type': 'authorization_code'}, form=True)
                if SCOPE not in token.get('scope', '').split():
                    raise ValueError('Google не предоставил доступ к Search Console. Повторите подключение и разрешите чтение данных.')
                if not token.get('refresh_token'):
                    raise ValueError('Google не вернул постоянный доступ. Повторите подключение с подтверждением разрешения.')
                token['expires_at'] = time.time() + token.get('expires_in', 3600)
                identity = http_json('https://openidconnect.googleapis.com/v1/userinfo', headers={'Authorization': 'Bearer ' + token['access_token']})
                if not identity.get('sub') or not identity.get('email'):
                    raise ValueError('Google не вернул идентификатор аккаунта. Повторите подключение.')
                account = state['account']
                existing = next((a for a in ACCOUNTS.records() if a.get('subject') == identity['sub']), None)
                if existing:
                    account = existing['id']
                elif not state.get('new'):
                    previous = next(a for a in ACCOUNTS.records() if a['id'] == account)
                    if previous.get('subject') and previous['subject'] != identity['sub']:
                        raise ValueError('Выбран другой Google-аккаунт. Используйте «Добавить аккаунт».')
                    # Legacy connections have no identity scope. Preserve their data if another portfolio is selected.
                    if not previous.get('subject'):
                        with ACCOUNTS.bind(account):
                            old_token = read_private('tokens.json')
                            if old_token:
                                with db() as c:
                                    old_sites = {r[0] for r in c.execute('SELECT id FROM sites WHERE active=1')}
                                new_sites = {s['siteUrl'] for s in http_json('https://www.googleapis.com/webmasters/v3/sites', headers={'Authorization':'Bearer '+token['access_token']}).get('siteEntry', [])}
                                if old_sites and not old_sites <= new_sites:
                                    raise ValueError('Состав сайтов отличается от основного аккаунта. Добавьте его как новый аккаунт, чтобы сохранить прежние данные.')
                with ACCOUNTS.bind(account):
                    if JOB.get('running') or INSIGHTS.job.get('running') or PORTFOLIO.job.get('running'):
                        raise ValueError('Дождитесь завершения загрузки этого аккаунта и повторите вход.')
                    init()
                    write_private('oauth.json', config)
                    write_private('tokens.json', token)
                    ACCOUNTS.save_record({'id': account, 'subject': identity['sub'], 'label': identity['email']})
                    save_setting('last_slot', None)
                    start_sync({})
                return self.redirect('/?auth=connected&account=' + account)
            if path == '/api/accounts':
                return self.send(ACCOUNTS.public())
            if path == '/api/collections':
                return self.send(PORTFOLIO.collections())
            if path == '/api/indexing':
                return self.send(PORTFOLIO.indexing())
            if path == '/api/hooks':
                return self.send(PORTFOLIO.hooks())
            if path == '/api/status':
                with LOCK:
                    job = dict(JOB)
                if not job.get('started'):
                    job = setting('last_job', job)
                    job['running'] = False
                return self.send({'account': ACCOUNTS.current(), 'configured': bool(read_private('oauth.json')), 'connected': bool(read_private('tokens.json')),
                                  'job': job, 'last_sync': setting('last_full_sync'), 'schedule': '00:00 и 17:00 · Europe/Minsk'})
            if path == '/api/dashboard':
                return self.send(dashboard(params))
            if path == '/api/detail':
                return self.send(detail(params))
            if path == '/api/alerts':
                return self.send(INSIGHTS.alerts())
            if path == '/api/opportunities':
                return self.send(INSIGHTS.opportunities())
            return self.send({'error': 'Не найдено'}, 404)
        except (ValueError, APIError) as e:
            return self.send({'error': str(e)}, 400)
        except Exception:
            return self.send({'error': 'Внутренняя ошибка. Перезапустите приложение и повторите запрос.'}, 500)

    def do_POST(self):
        try:
            with ACCOUNTS.bind(self.headers.get('X-GSC-Account', 'default'), validate=True):
                return self.handle_post()
        except ValueError as e:
            return self.send({'error': str(e)}, 400)

    def handle_post(self):
        if not self.valid_host() or not self.session() or self.headers.get('Origin') != BASE or self.headers.get('X-GSC-Request') != '1':
            return self.send({'error': 'Запрос отклонён'}, 403)
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if size > 2 * 1024 * 1024:
                raise ValueError('Слишком большой запрос')
            body = json.loads(self.rfile.read(size) or b'{}')
            if self.path == '/api/config':
                config = body.get('installed', {})
                if not config.get('client_id', '').endswith('.apps.googleusercontent.com') or not config.get('client_secret'):
                    raise ValueError('Нужен JSON OAuth-клиента типа Desktop app, скачанный из Google Cloud.')
                if JOB.get('running') or INSIGHTS.job.get('running') or PORTFOLIO.job.get('running'):
                    raise ValueError('Дождитесь завершения обновления.')
                if read_private('tokens.json'):
                    raise ValueError('Сначала отключите текущий аккаунт.')
                write_private('oauth.json', {'client_id': config['client_id'], 'client_secret': config['client_secret']})
                return self.send({'ok': True})
            if self.path == '/api/connect':
                config = read_private('oauth.json')
                if not config:
                    raise ValueError('Сначала загрузите OAuth JSON в настройках.')
                if JOB.get('running') or INSIGHTS.job.get('running') or PORTFOLIO.job.get('running'):
                    raise ValueError('Дождитесь завершения синхронизации.')
                verifier = secrets.token_urlsafe(64)
                state = secrets.token_urlsafe(32)
                OAUTH[state] = {'verifier': verifier, 'session': self.session(), 'created': time.time(), 'config': config,
                                'account': secrets.token_hex(16) if body.get('new') else ACCOUNTS.current(), 'new': bool(body.get('new'))}
                challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b'=').decode()
                url = 'https://accounts.google.com/o/oauth2/v2/auth?' + urllib.parse.urlencode({
                    'client_id': config['client_id'], 'redirect_uri': BASE + '/oauth/callback',
                    'response_type': 'code', 'scope': SCOPE + ' openid email', 'state': state, 'code_challenge': challenge,
                    'code_challenge_method': 'S256', 'access_type': 'offline', 'prompt': 'consent select_account'})
                return self.send({'url': url})
            if self.path == '/api/sync':
                return self.send(start_sync(body))
            if self.path == '/api/alerts/settings':
                return self.send(INSIGHTS.set_alert_settings(body))
            if self.path == '/api/alerts/ack':
                with db() as c:
                    c.execute('INSERT OR REPLACE INTO alert_states VALUES(?,?)', (str(body['id']), int(bool(body.get('acknowledged', True)))))
                return self.send({'ok': True})
            if self.path == '/api/alerts/refresh':
                today = datetime.now(PT).date()
                return self.send(start_sync({'start': str(today - timedelta(days=30)), 'end': str(today), 'type': 'web'}))
            if self.path == '/api/opportunities/scan':
                return self.send(INSIGHTS.start_opportunities())
            if self.path == '/api/site':
                return self.send(PORTFOLIO.save_site(body))
            if self.path == '/api/collections/save':
                return self.send(PORTFOLIO.save_collection(body))
            if self.path == '/api/indexing/import':
                return self.send(PORTFOLIO.import_indexing(body))
            if self.path == '/api/hooks/scan':
                return self.send(PORTFOLIO.start_scan())
            if self.path == '/api/disconnect':
                if JOB.get('running') or INSIGHTS.job.get('running') or PORTFOLIO.job.get('running'):
                    raise ValueError('Дождитесь завершения обновления.')
                (ACCOUNTS.path() / 'tokens.json').unlink(missing_ok=True)
                return self.send({'ok': True})
            return self.send({'error': 'Не найдено'}, 404)
        except (ValueError, APIError) as e:
            return self.send({'error': str(e)}, 400)
        except Exception:
            return self.send({'error': 'Не удалось выполнить действие.'}, 500)


def main():
    global BASE
    parser = argparse.ArgumentParser(description='GSC Desk — локальный дашборд')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    os.umask(0o077)
    for account in ACCOUNTS.records():
        ACCOUNTS.run(account['id'], init)
    BASE = 'http://127.0.0.1:' + str(args.port)
    try:
        server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    except OSError as error:
        if error.errno == errno.EADDRINUSE:
            print('Порт занят. Возможно, GSC Desk уже запущен: ' + BASE)
        else:
            print('Не удалось запустить локальный сервер: ' + str(error))
        return
    threading.Thread(target=scheduler, daemon=True).start()
    print('GSC Desk: ' + BASE + '\nОставьте это окно открытым. Для остановки: Ctrl+C.', flush=True)
    if not args.no_browser:
        webbrowser.open(BASE)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nGSC Desk остановлен.')
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
