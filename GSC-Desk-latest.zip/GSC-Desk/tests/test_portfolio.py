import json
import io
import time
import urllib.parse
import tempfile
import threading
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch
from test_app import app
from accounts import AccountMap


class PortfolioTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        app.DATA = Path(self.temp.name)
        self.old_job = app.JOB
        app.JOB = AccountMap(app.ACCOUNTS)
        app.init()
        self.site = 'sc-domain:example.test'
        with app.db() as c:
            c.execute('INSERT INTO sites(id,tag) VALUES(?,?)', (self.site, 'Legacy'))

    def tearDown(self):
        app.JOB = self.old_job
        self.temp.cleanup()

    def collection(self, name, kind='group', color='#4285f4'):
        return app.PORTFOLIO.save_collection({'kind':kind, 'name':name, 'color':color, 'sites':[self.site]})['id']

    def test_multiple_groups_and_favorite_preserve_memberships(self):
        first, second = self.collection('One'), self.collection('Two')
        label = self.collection('Ready', 'tag', '#ff9900')
        app.PORTFOLIO.save_site({'site':self.site, 'favorite':True, 'tag':'old stale label'})
        site = app.dashboard({})['sites'][0]
        self.assertEqual({g['id'] for g in site['groups']}, {first,second})
        self.assertEqual(site['labels'][0]['id'],label)
        self.assertEqual(site['labels'][0]['color'],'#ff9900')
        app.PORTFOLIO.save_site({'site':self.site,'groups':[second]})
        self.assertEqual(len(app.dashboard({})['sites'][0]['labels']),1)
        self.assertEqual(len(app.dashboard({})['sites'][0]['groups']),1)

    def test_legacy_migration_once(self):
        with app.db() as c:
            c.execute("DELETE FROM settings WHERE key='collections_v1'")
        app.init();app.init()
        groups=app.dashboard({})['sites'][0]['groups']
        self.assertEqual([g['name'] for g in groups],['Legacy'])
        app.PORTFOLIO.save_site({'site':self.site,'groups':[]})
        app.init()
        self.assertEqual(app.dashboard({})['sites'][0]['groups'],[])

    def test_bulk_edit_is_atomic_on_unknown_site(self):
        ident=self.collection('One')
        with self.assertRaises(ValueError):
            app.PORTFOLIO.save_collection({'id':ident,'kind':'group','name':'Renamed','sites':['sc-domain:unknown.test']})
        self.assertEqual(app.PORTFOLIO.collections()['collections'][0]['name'],'One')
        self.assertEqual(app.PORTFOLIO.collections()['collections'][0]['sites'],[self.site])

    def test_import_coverage_and_reject_malformed_without_overwrite(self):
        text='Date,Not indexed,Indexed\n2026-01-01,20,80\n2026-01-02,10,90\n'
        app.PORTFOLIO.import_indexing({'site':self.site,'csv':text})
        result=app.PORTFOLIO.indexing()['sites'][0]
        self.assertEqual((result['day'],result['indexed'],result['not_indexed']),('2026-01-02',90,10))
        with self.assertRaises(ValueError):
            app.PORTFOLIO.import_indexing({'site':self.site,'csv':text+'2026-01-03,-2,100\n'})
        self.assertEqual(app.PORTFOLIO.indexing()['sites'][0]['day'],'2026-01-02')
        app.PORTFOLIO.import_indexing({'site':self.site,'csv':'Дата;Не проиндексировано;Проиндексировано\n03.01.2026;9;91'})
        self.assertEqual(app.PORTFOLIO.indexing()['sites'][0]['indexed'],91)

    def test_account_credentials_data_and_worker_are_isolated(self):
        other='a'*32
        self.collection('Default only')
        app.write_private('tokens.json',{'refresh_token':'default-token'})
        app.JOB['running']=True
        app.ACCOUNTS.save_record({'id':other,'label':'Second test account'})
        with app.ACCOUNTS.bind(other):
            app.init()
            self.assertFalse(app.read_private('tokens.json'))
            self.assertFalse(app.dashboard({})['sites'])
            self.assertFalse(app.PORTFOLIO.collections()['collections'])
            self.assertFalse(app.JOB['running'])
            app.write_private('tokens.json',{'refresh_token':'second-token'})
            def worker():
                self.assertEqual(app.read_private('tokens.json')['refresh_token'],'second-token')
                app.save_setting('worker','second')
            thread=threading.Thread(target=app.ACCOUNTS.run,args=(other,worker))
            thread.start();thread.join()
            self.assertEqual(app.setting('worker'),'second')
        self.assertIsNone(app.setting('worker'))
        self.assertEqual(app.read_private('tokens.json')['refresh_token'],'default-token')
        self.assertTrue(app.JOB['running'])
        with self.assertRaises(ValueError):
            with app.ACCOUNTS.bind('../escape'): pass

    def test_first_impression_requires_observed_zero_coverage(self):
        end=datetime.now(app.PT).date()-timedelta(days=3)
        start=end-timedelta(days=5)
        with app.db() as c:
            c.execute('INSERT INTO site_observation VALUES(?,?)',(self.site,str(start)+'T00:00:00-08:00'))
        payload={'rows':[{'keys':[str(end)],'impressions':8}]}
        with patch.object(app,'query',return_value={'rows':[{'keys':['first query'],'impressions':8,'clicks':0,'position':9}]}):
            app.PORTFOLIO.observe(self.site,str(start),str(end),payload)
        hook=app.PORTFOLIO.hooks()['sites'][0]
        self.assertTrue(hook['confirmed'])
        self.assertEqual(hook['queries']['rows'][0]['keys'],['first query'])
        with app.db() as c:
            c.execute('DELETE FROM impression_days WHERE day=?',(str(start),))
        self.assertFalse(app.PORTFOLIO.hooks()['sites'][0]['confirmed'])

    def test_historical_positive_and_incomplete_are_not_new_hook(self):
        end=datetime.now(app.PT).date()-timedelta(days=3)
        start=end-timedelta(days=5)
        with patch.object(app,'query',return_value={'rows':[]}):
            app.PORTFOLIO.observe(self.site,str(start),str(end),{'rows':[{'keys':[str(start)],'impressions':8}], 'metadata':{'first_incomplete_date':str(start)}})
            self.assertFalse(app.PORTFOLIO.hooks()['sites'])
            app.PORTFOLIO.observe(self.site,str(start),str(end),{'rows':[{'keys':[str(start)],'impressions':8}]})
        self.assertFalse(app.PORTFOLIO.hooks()['sites'][0]['confirmed'])

    def test_oauth_add_account_preserves_original_and_deduplicates_identity(self):
        app.BASE='http://127.0.0.1:8765'
        app.write_private('tokens.json',{'refresh_token':'original'})
        app.write_private('oauth.json',{'client_id':'test.apps.googleusercontent.com','client_secret':'secret'})
        handler=object.__new__(app.Handler)
        handler.headers={'Host':'127.0.0.1:8765','Origin':app.BASE,'X-GSC-Request':'1','Content-Length':'13'}
        handler.session=lambda:'test-session'
        handler.send=lambda value,*a,**k:value
        handler.redirect=lambda value:value
        handler.path='/api/connect'
        handler.rfile=io.BytesIO(b'{"new": true}')
        response=handler.handle_post()
        state=urllib.parse.parse_qs(urllib.parse.urlparse(response['url']).query)['state'][0]
        new_account=app.OAUTH[state]['account']
        self.assertNotEqual(new_account,'default')
        handler.path='/oauth/callback?state='+state+'&code=fixture'
        token={'scope':app.SCOPE+' openid email','access_token':'new','refresh_token':'new-refresh','expires_in':3600}
        identity={'sub':'test-subject','email':'second@example.test'}
        with patch.object(app,'http_json',side_effect=[token,identity]),patch.object(app,'start_sync',return_value={'started':True}):
            redirect=handler.handle_get()
        self.assertIn('account='+new_account,redirect)
        self.assertEqual(app.read_private('tokens.json')['refresh_token'],'original')
        with app.ACCOUNTS.bind(new_account):
            self.assertEqual(app.read_private('tokens.json')['refresh_token'],'new-refresh')
            self.assertFalse(app.dashboard({})['sites'])
        # A second authorization of the same identity reuses that account's database.
        next_state='duplicate'
        app.OAUTH[next_state]={'verifier':'test','session':'test-session','created':time.time(),
            'config':app.read_private('oauth.json'),'account':'c'*32,'new':True}
        handler.path='/oauth/callback?state='+next_state+'&code=fixture'
        with patch.object(app,'http_json',side_effect=[token,identity]),patch.object(app,'start_sync',return_value={'started':True}):
            self.assertIn('account='+new_account,handler.handle_get())
        self.assertEqual(len(app.ACCOUNTS.records()),2)


if __name__=='__main__': unittest.main()
