import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch
from test_app import app


class InsightsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        app.DATA = Path(self.temp.name)
        app.init()
        self.site = 'sc-domain:insights.example'
        with app.db() as c:
            c.execute('INSERT INTO sites(id,last_sync) VALUES(?,?)', (self.site, app.now()))

    def tearDown(self):
        self.temp.cleanup()

    def history(self, recent=1, position=4, incomplete=None):
        end = datetime.now(app.PT).date() - timedelta(days=3)
        start = end - timedelta(days=20)
        rows = [{'keys': [str(start + timedelta(days=i))], 'clicks': 10 if i < 14 else recent,
                 'impressions': 100 if i < 14 else recent * 10, 'position': 4 if i < 14 else position}
                for i in range(21) if i < 14 or recent]
        payload = {'rows': rows, 'metadata': {'first_incomplete_date': str(end)} if incomplete else {}}
        with app.db() as c:
            c.execute('INSERT OR REPLACE INTO reports VALUES(?,?,?,?,?,?)',
                      (self.site, str(start), str(end), 'web', json.dumps(payload), app.now()))
        return end

    def test_calendar_zeros_trigger_visibility_alert(self):
        self.history(recent=0)
        data = app.INSIGHTS.alerts()
        self.assertFalse(data['insufficient'])
        self.assertEqual({a['kind'] for a in data['alerts']}, {'clicks_drop', 'impressions_drop', 'no_impressions'})

    def test_incomplete_history_does_not_trigger_drop(self):
        self.history(recent=0, incomplete=True)
        data = app.INSIGHTS.alerts()
        self.assertEqual(data['insufficient'], [self.site])
        self.assertFalse(data['alerts'])

    def test_position_and_acknowledgement(self):
        self.history(recent=10, position=8)
        alert = app.INSIGHTS.alerts()['alerts'][0]
        self.assertEqual(alert['kind'], 'position_drop')
        with app.db() as c:
            c.execute('INSERT INTO alert_states VALUES(?,1)', (alert['id'],))
        self.assertTrue(app.INSIGHTS.alerts()['alerts'][0]['acknowledged'])

    def test_hourly_window_excludes_other_hours_and_aggregates(self):
        start = datetime(2026, 11, 1, 8, tzinfo=timezone.utc)
        end = start + timedelta(hours=24)
        def query(site, body):
            rows = []
            for i in (-1, 0, 1, 23, 24):
                keys = [(start + timedelta(hours=i)).isoformat()]
                if len(body['dimensions']) > 1:
                    keys += ['same query']
                rows.append({'keys': keys, 'clicks': 1, 'impressions': 10, 'position': 5})
            self.assertEqual(body['dataState'], 'hourly_all')
            return {'rows': rows}
        with patch.object(app.INSIGHTS, 'window', return_value=(start, end)), patch.object(app, 'query', side_effect=query):
            report = app.INSIGHTS.hourly_detail(self.site, 'web', 'query', [], 0)
        self.assertEqual(len(report['series']), 3)
        self.assertEqual(report['totals']['clicks'], 3)
        self.assertEqual(report['rows'][0]['clicks'], 3)
        self.assertAlmostEqual(report['rows'][0]['ctr'], .1)

    def test_missing_page_is_not_zero_traffic(self):
        def row(label, clicks, position=5):
            return {'keys': [label], 'clicks': clicks, 'impressions': 1000, 'ctr': clicks / 1000, 'position': position}
        end = datetime.now(app.PT).date() - timedelta(days=3)
        with patch.object(app.INSIGHTS, 'fetch_rows', side_effect=[
            ([row('opportunity', 10), row('outside', 10, 16)], False),
            ([row('/present', 20)], False),
            ([row('/present', 50), row('/missing', 50)], False)]):
            app.INSIGHTS.scan_site(self.site, end - timedelta(days=27), end)
        result = app.INSIGHTS.opportunities()['sites'][0]
        self.assertEqual([r['label'] for r in result['queries']], ['opportunity'])
        self.assertEqual([r['label'] for r in result['pages']], ['/present'])
        self.assertEqual(result['pages'][0]['drop'], 60)

    def test_invalid_threshold_rejected(self):
        settings = app.INSIGHTS.alerts()['settings']
        with self.assertRaises(ValueError):
            app.INSIGHTS.set_alert_settings(dict(settings, drop=101))


if __name__ == '__main__':
    unittest.main()
