import importlib.util
import json
import tempfile
import threading
import time
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('gsc_app', Path(__file__).parents[1] / 'app.py')
app = importlib.util.module_from_spec(spec)
spec.loader.exec_module(app)


class AppTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        app.DATA = Path(self.temp.name)
        app.JOB_LOCK = threading.Lock()
        app.JOB = {'running': False, 'errors': [], 'done': 0, 'total': 0}
        app.init()
        self.start, self.end, self.kind = app.date_range({})

    def tearDown(self):
        self.temp.cleanup()

    def add_site(self, site='sc-domain:test.example'):
        with app.db() as c:
            c.execute('INSERT INTO sites(id) VALUES(?)', (site,))
        return site

    def test_weighted_position_and_ctr(self):
        result = app.total_rows([{'clicks': 10, 'impressions': 100, 'position': 2}, {'clicks': 1, 'impressions': 10, 'position': 20}])
        self.assertAlmostEqual(result['ctr'], .1)
        self.assertAlmostEqual(result['position'], 400 / 110)
        self.assertEqual(app.total_rows([])['impressions'], 0)

    def test_date_range_validation(self):
        start, end, _ = app.date_range({})
        self.assertEqual((app.date.fromisoformat(end) - app.date.fromisoformat(start)).days, 27)
        for params in ({'start': end, 'end': start}, {'start': '2000-01-01'}, {'type': 'invalid'}, {'end': str(app.datetime.now(app.PT).date() + timedelta(days=1))}):
            with self.assertRaises(ValueError):
                app.date_range(params)

    def test_minsk_schedule_and_catch_up(self):
        for hour, minute, expected in [(0, 0, '00:00'), (16, 59, '00:00'), (17, 0, '17:00'), (23, 59, '17:00')]:
            dt = datetime(2026, 11, 12, hour, minute, tzinfo=app.MINSK)
            self.assertIn('T' + expected, app.due_slot(dt))
        self.assertIn('T17:00', app.due_slot(datetime.fromisoformat('2026-11-12T14:00:00+00:00')))

    def test_discovery_all_sites_and_removed_access(self):
        self.add_site('sc-domain:removed.example')
        items = [{'siteUrl': 'sc-domain:site%d.example' % i, 'permissionLevel': 'siteOwner'} for i in range(350)]
        items.append({'siteUrl': 'sc-domain:unverified.example', 'permissionLevel': 'siteUnverifiedUser'})
        with patch.object(app, 'google', return_value={'siteEntry': items}):
            self.assertEqual(len(app.discover()), 350)
        with app.db() as c:
            self.assertEqual(c.execute('SELECT SUM(active) FROM sites').fetchone()[0], 350)
            self.assertEqual(c.execute("SELECT active FROM sites WHERE id='sc-domain:removed.example'").fetchone()[0], 0)

    def test_report_cache_and_detail_invalidation(self):
        site = self.add_site()
        with app.db() as c:
            c.execute('INSERT INTO details VALUES(?,?,?)', (json.dumps([site, 'old']), '{}', time.time()))
        result = {'rows': [{'keys': [self.end], 'clicks': 5, 'impressions': 100, 'position': 4}], 'metadata': {'first_incomplete_date': self.end}}
        with patch.object(app, 'query', return_value=result):
            app.fetch_report(site, self.start, self.end, self.kind)
        data = app.dashboard({})['sites'][0]
        self.assertEqual(data['report']['totals']['clicks'], 5)
        self.assertEqual(data['report']['metadata']['first_incomplete_date'], self.end)
        with app.db() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM details').fetchone()[0], 0)

    def test_failed_refresh_preserves_last_good_data(self):
        site = self.add_site()
        with patch.object(app, 'query', return_value={'rows': [{'keys': [self.end], 'clicks': 7, 'impressions': 30, 'position': 3}]}):
            app.fetch_report(site, self.start, self.end, self.kind)
        with patch.object(app, 'query', side_effect=app.APIError('offline')):
            with self.assertRaises(app.APIError):
                app.fetch_report(site, self.start, self.end, self.kind)
        self.assertEqual(app.dashboard({})['sites'][0]['report']['totals']['clicks'], 7)

    def test_350_site_queue_isolates_errors(self):
        sites = [self.add_site('sc-domain:site%d.example' % i) for i in range(350)]
        def load(site, *args):
            if site == sites[17]:
                raise app.APIError('Access denied')
        app.JOB_LOCK.acquire()
        with patch.object(app, 'discover', return_value=sites), patch.object(app, 'fetch_report', side_effect=load) as fetch:
            app.sync_worker(self.start, self.end, self.kind, None, 'slot')
        self.assertEqual(fetch.call_count, 350)
        self.assertEqual(app.JOB['done'], 350)
        self.assertEqual(len(app.JOB['errors']), 1)
        self.assertFalse(app.JOB['running'])
        self.assertFalse(app.JOB_LOCK.locked())
        self.assertEqual(app.setting('last_slot'), 'slot')

    def test_scheduled_sync_refreshes_watched_range(self):
        site = self.add_site()
        app.save_setting('watched_range', {'start': self.start, 'end': self.end, 'type': 'image'})
        app.JOB_LOCK.acquire()
        with patch.object(app, 'discover', return_value=[site]), patch.object(app, 'fetch_report') as fetch:
            app.sync_worker(self.start, self.end, self.kind, None, 'slot')
        self.assertEqual(fetch.call_count, 2)
        self.assertEqual(app.JOB['total'], 2)
        self.assertEqual(fetch.call_args[0][-1], 'image')

    def test_duplicate_sync_suppressed(self):
        app.write_private('tokens.json', {'refresh_token': 'test'})
        app.JOB_LOCK.acquire()
        result = app.start_sync({})
        self.assertFalse(result['started'])
        app.JOB_LOCK.release()

    def test_detail_page_filters_totals_and_cache(self):
        site = self.add_site()
        calls = []
        def query(site, body):
            calls.append(body)
            if body['dimensions'] == ['date']:
                return {'rows': [{'keys': [self.end], 'clicks': 500, 'impressions': 1000, 'position': 2}]}
            return {'rows': [{'keys': ['q%d' % i], 'clicks': 1, 'impressions': 10, 'position': 4, 'ctr': .1} for i in range(51)]}
        params = {'site': site, 'dimension': 'query', 'offset': 50, 'country': 'ita', 'device': 'MOBILE', 'query': 'test'}
        with patch.object(app, 'query', side_effect=query):
            first = app.detail(params)
            second = app.detail(params)
        self.assertEqual(len(calls), 2)
        self.assertEqual(first, second)
        self.assertTrue(first['has_more'])
        self.assertEqual(len(first['rows']), 50)
        self.assertEqual(first['totals']['clicks'], 500)  # Never sum query rows into headline totals.
        self.assertEqual(calls[1]['startRow'], 50)
        self.assertEqual(len(calls[0]['dimensionFilterGroups'][0]['filters']), 3)

    def test_unsupported_query_dimension(self):
        site = self.add_site()
        with self.assertRaises(ValueError):
            app.detail({'site': site, 'type': 'discover', 'dimension': 'query'})

    def test_token_refresh_retains_refresh_token(self):
        app.write_private('oauth.json', {'client_id': 'test', 'client_secret': 'secret'})
        app.write_private('tokens.json', {'refresh_token': 'refresh', 'expires_at': 0})
        with patch.object(app, 'http_json', return_value={'access_token': 'new', 'expires_in': 3600}):
            self.assertEqual(app.access_token(), 'new')
        self.assertEqual(app.read_private('tokens.json')['refresh_token'], 'refresh')
        self.assertEqual((app.DATA / 'tokens.json').stat().st_mode & 0o777, 0o600)

    def test_property_url_escaped(self):
        with patch.object(app, 'google', return_value={}) as google:
            app.query('https://example.com/path/', {})
        self.assertEqual(google.call_args[0][0], 'sites/https%3A%2F%2Fexample.com%2Fpath%2F/searchAnalytics/query')


if __name__ == '__main__':
    unittest.main()
