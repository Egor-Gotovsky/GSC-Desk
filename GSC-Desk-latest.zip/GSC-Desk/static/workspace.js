'use strict';
// Explicit per-view state: a site report never mutates the portfolio date range.
const metrics = [
  {key:'clicks',label:'Клики',control:'showClicks',color:'#4285f4'},
  {key:'impressions',label:'Показы',control:'showImpressions',color:'#673ab7'},
  {key:'ctr',label:'CTR',control:'showCtr',color:'#00897b'},
  {key:'position',label:'Позиция',control:'showPosition',color:'#ef6c00'}
];
const charts = new Map();
let chartSequence=0, chartHover=null, page='portfolio', alertsData=null, opportunityData=null;
let analysisTimer=null, previousSync='', alertsRefreshAt=0, analysisRequest=0;
const metricValue=(key,value)=>key==='ctr'?pct(value):key==='position'?(value>0?dec(value):'—'):fmt(value);
function hourWindow(){const end=new Date();end.setUTCMinutes(0,0,0);end.setUTCHours(end.getUTCHours()+1);return {window_start:new Date(end-86400000).toISOString(),window_end:end.toISOString()}}
function chartTicks(bounds,rows){
  if(bounds.period==='24h'){
    const window=bounds.window_start?bounds:hourWindow();
    return Array.from({length:24},(_,i)=>new Date(new Date(window.window_start).getTime()+i*3600000).toISOString());
  }
  const ticks=[];for(let d=bounds.start;d<=bounds.end;d=shift(d,1))ticks.push(d);return ticks;
}
function chartDate(key,hourly=false){return new Date(key.length===10?key+'T12:00:00Z':key).toLocaleString('ru-RU',{timeZone:'America/Los_Angeles',day:'numeric',month:'short',...(hourly?{hour:'2-digit',minute:'2-digit'}:{})})}
function drawChart(rows,bounds,selected=['clicks','impressions'],site=''){
  const id='plot-'+(++chartSequence),hourly=bounds.period==='24h';
  const ticks=chartTicks(bounds,rows),lookup=new Map(rows.map(r=>[hourly?new Date(r.keys[0]).toISOString():r.keys[0],r]));
  const points=ticks.map(k=>lookup.get(k)||null),visible=metrics.filter(m=>selected.includes(m.key));
  const w=900,h=220,pad=12,plotW=w-pad*2,plotH=h-28;
  const x=i=>pad+i/(ticks.length-1||1)*plotW;
  const scales=Object.fromEntries(visible.map(m=>[m.key,Math.max(.001,...points.map(r=>r?.[m.key]||0))]));
  let lines='<path class="chart-gridline" d="M12 55 H888 M12 110 H888 M12 165 H888 M12 210 H888"/>';
  for(const metric of visible){let path='',connected=false;points.forEach((r,i)=>{if(!r){connected=false;return}const y=h-10-(r[metric.key]||0)/scales[metric.key]*plotH;path+=(connected?' L':' M')+x(i)+' '+y;connected=true;});lines+=`<path d="${path}" class="line-${metric.key}" fill="none" stroke="${metric.color}" stroke-width="2" vector-effect="non-scaling-stroke"/>`;}
  const events=notes.filter(n=>n.site===site&&ticks.some(k=>k.slice(0,10)===n.day));
  for(const event of events){const i=ticks.findIndex(k=>k.slice(0,10)===event.day);lines+=`<g class="chart-event"><line x1="${x(i)}" x2="${x(i)}" y1="8" y2="210"/><circle cx="${x(i)}" cy="10" r="4"/><title>${esc(event.day+' · '+event.text)}</title></g>`;}
  charts.set(id,{ticks,points,visible,x,scales,h,plotH,hourly,site});
  if(charts.size>600)for(const key of charts.keys())if(!document.getElementById(key)&&key!==id)charts.delete(key);
  return `<div class="gsc-chart" id="${id}"><svg class="chart" viewBox="0 0 900 220" preserveAspectRatio="none" role="img" aria-label="График эффективности. Наведите курсор или используйте стрелки." tabindex="0">${lines}<g class="chart-focus" visibility="hidden"><line class="chart-crosshair" x1="0" x2="0" y1="0" y2="220"/>${visible.map(m=>`<circle data-metric="${m.key}" r="4" fill="${m.color}" stroke="var(--surface,#fff)" stroke-width="2"/>`).join('')}</g></svg><div class="chart-tooltip" role="status" hidden></div><div class="chart-labels"><span>${chartDate(ticks[0],hourly)}</span><span>${hourly?'По часам · PT · предварительно':'По дням · независимые шкалы'}</span><span>${chartDate(ticks.at(-1),hourly)}</span></div>${!visible.length?'<p class="help">Выберите метрику над графиком.</p>':''}</div>`;
}
chart=function(rows,start=range.start,end=range.end){return drawChart(rows,{...range,start,end})};
function hoverChart(wrapper,index){
  const state=charts.get(wrapper.id);if(!state)return;
  index=Math.max(0,Math.min(state.ticks.length-1,index));const row=state.points[index],key=state.ticks[index];
  const focus=wrapper.querySelector('.chart-focus');focus.setAttribute('visibility','visible');
  const line=focus.querySelector('line');line.setAttribute('x1',state.x(index));line.setAttribute('x2',state.x(index));
  for(const circle of focus.querySelectorAll('circle')){const metric=circle.dataset.metric;circle.setAttribute('visibility',row?'visible':'hidden');if(row){circle.setAttribute('cx',state.x(index));circle.setAttribute('cy',state.h-10-(row[metric]||0)/state.scales[metric]*state.plotH)}}
  const site=state.site||wrapper.closest('.site-card')?.querySelector('[data-open]')?.dataset.open;
  const events=notes.filter(n=>n.site===site&&n.day===key.slice(0,10));
  const tooltip=wrapper.querySelector('.chart-tooltip');
  tooltip.innerHTML=`<strong>${esc(chartDate(key,state.hourly))}${state.hourly?' · PT':''}</strong>${row?metrics.map(m=>`<div class="tooltip-row"><span class="tooltip-dot ${m.key}"></span><span>${m.label}</span><b>${metricValue(m.key,row[m.key])}</b></div>`).join(''):'<p>Нет данных за этот интервал</p>'}${events.map(n=>'<p class="tooltip-event">'+esc(n.text)+'</p>').join('')}`;
  tooltip.hidden=false;const width=wrapper.clientWidth,tipWidth=Math.min(260,width);tooltip.style.width=tipWidth+'px';tooltip.style.left=Math.max(0,Math.min(width-tipWidth,state.x(index)/900*width-tipWidth/2))+'px';
  chartHover={wrapper,index};
}
document.addEventListener('pointermove',event=>{const svg=event.target.closest('.gsc-chart svg');if(!svg)return;const wrapper=svg.closest('.gsc-chart'),state=charts.get(wrapper.id),rect=svg.getBoundingClientRect();if(state)hoverChart(wrapper,Math.round(((event.clientX-rect.left)/rect.width*900-12)/876*(state.ticks.length-1)))});
document.addEventListener('pointerout',event=>{const wrapper=event.target.closest('.gsc-chart');if(wrapper&&!wrapper.contains(event.relatedTarget)){wrapper.querySelector('.chart-tooltip').hidden=true;wrapper.querySelector('.chart-focus').setAttribute('visibility','hidden')}});
document.addEventListener('keydown',event=>{const wrapper=event.target.closest('.gsc-chart');if(wrapper&&['ArrowLeft','ArrowRight'].includes(event.key)){event.preventDefault();hoverChart(wrapper,(chartHover?.wrapper===wrapper?chartHover.index:0)+(event.key==='ArrowRight'?1:-1))}});

// Short periods are shared between the portfolio and the independent site view.
$('preset').insertAdjacentHTML('afterbegin','<option value="24h">24 часа</option><option value="3">3 дня</option>');
function makeRange(value,current){if(value==='24h')return {...current,start:shift(ptToday(),-1),end:ptToday(),period:'24h'};return {...current,start:shift(ptToday(),1-Number(value)),end:ptToday(),period:'daily'}}
function validBounds(bounds){return bounds.start&&bounds.end&&bounds.start<=bounds.end&&bounds.end<=ptToday()}
applyRange=async function(){const next={start:$('start').value,end:$('end').value,type:$('searchType').value,period:$('preset').value==='24h'?'24h':'daily'};if(!validBounds(next))return toast('Проверьте даты диапазона');range=next;limit=30;await loadDashboard();if(!demo&&status.connected&&sites.some(s=>s.active&&!s.report))await refresh()};
$('preset').onchange=()=>{if($('preset').value==='custom')return;const next=makeRange($('preset').value,range);$('start').value=next.start;$('end').value=next.end;applyRange()};
$('applyRange').onclick=applyRange;$('searchType').onchange=applyRange;
for(const id of ['start','end'])$(id).onchange=()=>{$('preset').value='custom'};
quickPeriods.insertAdjacentHTML('afterbegin','<button data-days="24h">24 часа</button><button data-days="3">3 дня</button>');
const siteType=document.createElement('select');siteType.id='siteSearchType';siteType.setAttribute('aria-label','Тип поиска сайта');siteType.innerHTML=$('searchType').innerHTML;detailControls.append(siteType);
quickPeriods.onclick=event=>{const value=event.target.dataset.days;if(!value)return;siteRange=makeRange(value,siteRange||range);$('siteStart').value=siteRange.start;$('siteEnd').value=siteRange.end;offset=0;for(const button of quickPeriods.children)button.classList.toggle('selected',button===event.target);loadDetail()};
$('sitePeriod').onclick=()=>{const bounds={...siteRange,start:$('siteStart').value,end:$('siteEnd').value,period:'daily'};if(!validBounds(bounds))return toast('Проверьте даты');siteRange=bounds;offset=0;for(const b of quickPeriods.children)b.classList.remove('selected');loadDetail()};
siteType.onchange=()=>{siteRange.type=siteType.value;if(['discover','googleNews'].includes(siteType.value)&&dimension==='query')dimension='page';offset=0;loadDetail()};
openDetail=async function(id){activeSite=sites.find(s=>s.id===id);if(!activeSite)return;siteRange={...range};$('siteStart').value=siteRange.start;$('siteEnd').value=siteRange.end;siteType.value=siteRange.type;dimension=['discover','googleNews'].includes(range.type)?'page':'query';offset=0;for(const key of ['queryFilter','pageFilter','countryFilter','deviceFilter'])$(key).value='';$('detailTitle').textContent=domain(id);$('siteTag').value=activeSite.tag||'';$('openGsc').href='https://search.google.com/search-console/performance/search-analytics?resource_id='+encodeURIComponent(id);for(const b of quickPeriods.children)b.classList.toggle('selected',b.dataset.days===(range.period==='24h'?'24h':$('preset').value));$('detailDialog').showModal();await loadDetail()};
function drawSiteChart(){if(detailData)$('detailChart').innerHTML=drawChart(detailData.series,{...siteRange,...(detailData.period==='24h'?{...hourWindow(),window_start:detailData.window_start,window_end:detailData.window_end}: {})},metrics.filter(m=>$(m.control).checked).map(m=>m.key),activeSite?.id||'')}
for(const metric of metrics)$(metric.control).onchange=drawSiteChart;
loadDetail=async function(force=false){
  if(!activeSite)return;const request=++detailRequest,selectedSite=activeSite.id,bounds={...siteRange};detailData=null;
  $('detailDates').textContent=bounds.period==='24h'?'Последние 24 часа · почасовые данные · PT':`${bounds.start} — ${bounds.end}`;
  $('detailStatus').textContent='Загружаем отчёт…';$('detailSummary').innerHTML=summaryHTML(null,['','','','']);$('detailChart').innerHTML='';$('detailRows').innerHTML='<tr><td colspan="5">Загрузка…</td></tr>';$('prevPage').disabled=true;$('nextPage').disabled=true;
  for(const b of $('detailTabs').querySelectorAll('button'))b.classList.toggle('active',b.dataset.dim===dimension);
  $('dimensionLabel').textContent={query:'Запрос',page:'Страница',country:'Страна',device:'Устройство'}[dimension];
  try{const params={...bounds,site:selectedSite,dimension,offset,query:$('queryFilter').value,page:$('pageFilter').value,country:$('countryFilter').value.toLowerCase(),device:$('deviceFilter').value,...(force?{force:'1'}:{})};
    const data=demo?demoSiteReport(params):await api('/api/detail?'+qs(params));if(request!==detailRequest||activeSite?.id!==selectedSite)return;detailData=data;
    $('detailSummary').innerHTML=summaryHTML(data.totals,['','','','']);drawSiteChart();
    $('detailRows').innerHTML=data.rows.length?data.rows.map(r=>`<tr><td>${esc(r.keys[0])}</td>${metrics.map(m=>'<td>'+metricValue(m.key,r[m.key])+'</td>').join('')}</tr>`).join(''):'<tr><td colspan="5">Нет данных по выбранным условиям.</td></tr>';
    $('detailStatus').textContent=(demo?'Демо · ':'')+'Загружено '+nice(data.updated)+(bounds.period==='24h'?' · Почасовые данные предварительные':'')+(data.metadata?.first_incomplete_date?' · Неполные данные с '+data.metadata.first_incomplete_date:'')+(data.truncated?' · Достигнут лимит детализации API':'');
    $('pageLabel').textContent=data.rows.length?`${offset+1}–${offset+data.rows.length}`:'0 строк';$('prevPage').disabled=offset===0;$('nextPage').disabled=!data.has_more;
  }catch(error){if(request!==detailRequest)return;$('detailStatus').textContent=error.message;$('detailRows').innerHTML='<tr><td colspan="5">Не удалось загрузить отчёт. Попробуйте ещё раз.</td></tr>'}
};
refresh=async function(site){if(demo)return toast('Демонстрационные данные: Google не запрашивается');if(!status.connected)return $('setupDialog').showModal();try{const bounds=site&&activeSite?.id===site?siteRange:range;const result=await api('/api/sync',{...bounds,...(site?{site}:{})});toast(result.started?'Обновление запущено':'Уже идёт обновление. Дождитесь завершения.')}catch(error){toast(error.message)}};

// List selector and table view cover both meanings of a site list on the dashboard.
const siteSelector=document.createElement('select');siteSelector.id='siteSelector';siteSelector.setAttribute('aria-label','Список сайтов');siteSelector.innerHTML='<option value="">Все сайты</option>';document.querySelector('.filter-row').prepend(siteSelector);
const viewSelector=document.createElement('select');viewSelector.setAttribute('aria-label','Вид дашборда');viewSelector.innerHTML='<option value="cards">Карточки</option><option value="list">Список</option>';document.querySelector('.filter-row').append(viewSelector);viewSelector.value=localRead('gsc-view','cards');
const listView=document.createElement('div');listView.id='siteList';listView.className='table-wrap';$('grid').after(listView);
const baseFiltered=filteredSites;filteredSites=function(){const selected=siteSelector.value;return baseFiltered().filter(s=>!selected||s.id===selected)};
siteSelector.onchange=()=>{limit=30;render()};viewSelector.onchange=()=>{localStorage.setItem('gsc-view',JSON.stringify(viewSelector.value));render()};
const baseRender=render;render=function(){const selected=siteSelector.value;siteSelector.innerHTML='<option value="">Все сайты</option>'+sites.map(s=>`<option value="${esc(s.id)}">${esc(domain(s.id))}</option>`).join('');siteSelector.value=selected;baseRender();const list=viewSelector.value==='list';$('grid').hidden=list;listView.hidden=!list;
  if(list){listView.innerHTML='<table><thead><tr><th>Сайт</th><th>Клики</th><th>Показы</th><th>CTR</th><th>Позиция</th><th>Группа</th><th>Обновлено</th></tr></thead><tbody>'+filteredSites().slice(0,limit).map(s=>`<tr><td><button class="text-button" data-site="${esc(s.id)}">${esc(domain(s.id))}</button></td>${metrics.map(m=>'<td>'+(s.report?metricValue(m.key,s.report.totals[m.key]):'—')+'</td>').join('')}<td>${esc(s.tag)}</td><td>${esc(nice(s.report_updated))}</td></tr>`).join('')+'</tbody></table>'}
  if(range.period==='24h')$('rangeCaption').textContent='Последние 24 часа · почасовые данные PT';
};listView.onclick=e=>{const button=e.target.closest('[data-site]');if(button)openDetail(button.dataset.site)};

// Dedicated local routes, with browser Back/Forward support.
const portfolioChildren=[...document.querySelector('main').children];
const analysisPage=document.createElement('section');analysisPage.id='analysisPage';analysisPage.hidden=true;document.querySelector('main').append(analysisPage);
const problemsButton=[...document.querySelectorAll('.filter-row button')].find(b=>b.textContent==='Проблемы портфеля');problemsButton.onclick=()=>navigate('problems');
const opportunitiesButton=addAction(document.querySelector('.filter-row'),'Возможности',()=>navigate('opportunities'));
const alertBadge=addAction(document.querySelector('.header-right'),'Алерты',()=>navigate('problems'));
function navigate(target){location.hash=target==='portfolio'?'':target}
function route(){page=['problems','opportunities','indexing','hooks'].includes(location.hash.slice(1))?location.hash.slice(1):'portfolio';document.body.dataset.page=page;clearTimeout(analysisTimer);analysisRequest++;portfolioChildren.forEach(el=>{el.hidden=page!=='portfolio'});analysisPage.hidden=page==='portfolio';if(page==='portfolio'){render();$('notice').hidden=!$('notice').textContent;$('progressWrap').hidden=!status.job?.running;return}if(page==='problems')showProblems();else if(page==='opportunities')showOpportunities();else if(page==='indexing'&&typeof showIndexing==='function')showIndexing();else if(page==='hooks'&&typeof showHooks==='function')showHooks()}
window.addEventListener('hashchange',route);
const baseHome=$('home').onclick;$('home').onclick=()=>{navigate('portfolio');baseHome()};
const problemNames={clicks_drop:'Падение кликов',impressions_drop:'Падение показов',no_impressions:'Нет показов',position_drop:'Ухудшение позиции',sync_error:'Ошибка синхронизации',stale:'Давно не обновлялся'};
function analysisHeading(title,description){return `<div class="title-row"><div><div class="eyebrow">GSC DESK / АНАЛИТИКА</div><h1>${title}</h1><p class="subtitle">${description}</p></div><button class="button" id="backPortfolio">← Все сайты</button></div>${demo?'<div class="notice demo">Демонстрационный режим · Все цифры вымышлены.</div>':''}`}
async function getAlerts(){const data=demo?demoAlerts():await api('/api/alerts');alertsData=data;const unread=data.alerts.filter(a=>!a.acknowledged).length;alertBadge.textContent='Алерты'+(unread?' · '+unread:'');return data}
async function showProblems(){
  analysisPage.innerHTML=analysisHeading('Проблемы портфеля','Сигналы по полной дневной истории, независимо от периода на дашборде.')+'<p>Загрузка анализа…</p>';$('backPortfolio').onclick=()=>navigate('portfolio');const request=++analysisRequest;
  try{await getAlerts();if(request!==analysisRequest||page!=='problems')return;const data=alertsData;
    analysisPage.innerHTML=analysisHeading('Проблемы портфеля','Алерты пересчитываются после синхронизации. Последние неполные дни не участвуют в сравнении.')+`<div class="filter-row"><select id="problemKind" aria-label="Тип проблемы"><option value="">Все проблемы</option>${Object.entries(problemNames).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select><select id="problemSeverity" aria-label="Важность"><option value="">Любая важность</option><option value="critical">Критичные</option><option value="warning">Требуют внимания</option></select><select id="problemRead" aria-label="Статус алерта"><option value="">Все статусы</option><option value="new">Новые</option><option value="read">Просмотренные</option></select><input class="group-input compact-input" id="problemSearch" placeholder="Сайт или группа…"><button class="button" id="refreshAlerts">Обновить историю</button></div><details class="analysis-settings"><summary>Настройки алертов</summary><div class="detail-filters">${[['drop','Падение, %'],['min_clicks','Минимум кликов за неделю'],['min_impressions','Минимум показов за неделю'],['position','Ухудшение позиции'],['stale_hours','Без обновления, ч.']].map(([key,label])=>`<label>${label}<input type="number" id="alert-${key}" value="${data.settings[key]}" min="0.5" step="0.5"></label>`).join('')}<button class="button primary" id="saveAlertSettings">Сохранить</button></div></details><p class="help">${data.start} — ${data.end}. Последние 7 полных дней сравниваются с недельным средним предыдущих 14 дней. Недостаточно истории: ${data.insufficient.length} из ${data.total_sites}. «Обновить историю» загрузит 31 день.</p><div id="analysisMessage" class="help"></div><div class="table-wrap" id="problemTable"></div>`;
    $('backPortfolio').onclick=()=>navigate('portfolio');for(const id of ['problemKind','problemSeverity','problemRead'])$(id).onchange=renderProblems;$('problemSearch').oninput=renderProblems;
    $('saveAlertSettings').onclick=async()=>{const settings=Object.fromEntries(Object.keys(data.settings).map(k=>[k,Number($('alert-'+k).value)]));try{if(demo){toast('В демо пороги не сохраняются');return}await api('/api/alerts/settings',settings);await showProblems()}catch(e){toast(e.message)}};
    $('refreshAlerts').onclick=async()=>{if(demo)return toast('В демо история вымышлена');try{const result=await api('/api/alerts/refresh',{});$('analysisMessage').textContent=result.started?'История обновляется в фоне. Сигналы появятся после загрузки.':'Уже выполняется синхронизация.'}catch(e){toast(e.message)}};
    renderProblems();
  }catch(e){if(request===analysisRequest)analysisPage.innerHTML=analysisHeading('Проблемы портфеля','')+'<p>'+esc(e.message)+'</p>';if($('backPortfolio'))$('backPortfolio').onclick=()=>navigate('portfolio')}
}
function renderProblems(){const q=$('problemSearch').value.toLowerCase();const items=alertsData.alerts.filter(a=>(!$('problemKind').value||a.kind===$('problemKind').value)&&(!$('problemSeverity').value||a.severity===$('problemSeverity').value)&&(!$('problemRead').value||(a.acknowledged? 'read':'new')===$('problemRead').value)&&(!q||(a.site+' '+a.tag).toLowerCase().includes(q)));$('problemTable').innerHTML='<table><thead><tr><th>Сайт / группа</th><th>Проблема</th><th>Подробности</th><th>Статус</th></tr></thead><tbody>'+items.map(a=>`<tr><td><button class="text-button" data-open-alert="${esc(a.site)}">${esc(domain(a.site))}</button><small>${esc(a.tag)}</small></td><td><span class="severity ${a.severity}">${esc(a.title)}</span></td><td>${esc(a.message)}</td><td><button class="button small" data-ack="${esc(a.id)}">${a.acknowledged?'Просмотрено ✓':'Отметить просмотренным'}</button></td></tr>`).join('')+'</tbody></table>'+(!items.length?'<div class="empty">Нет сигналов по выбранным условиям. При неполной истории это не означает отсутствие проблем.</div>':'');
  $('problemTable').onclick=async event=>{const open=event.target.closest('[data-open-alert]');if(open)return openDetail(open.dataset.openAlert);const button=event.target.closest('[data-ack]');if(!button)return;const alert=alertsData.alerts.find(a=>a.id===button.dataset.ack);try{if(!demo)await api('/api/alerts/ack',{id:alert.id,acknowledged:!alert.acknowledged});alert.acknowledged=!alert.acknowledged;renderProblems();alertBadge.textContent='Алерты · '+alertsData.alerts.filter(a=>!a.acknowledged).length}catch(e){toast(e.message)}};
}

async function showOpportunities(){
  analysisPage.innerHTML=analysisHeading('Возможности','Запросы для роста CTR и страницы, которые теряют трафик.')+'<p>Загрузка…</p>';$('backPortfolio').onclick=()=>navigate('portfolio');
  const request=++analysisRequest;try{opportunityData=demo?demoOpportunities():await api('/api/opportunities');if(request!==analysisRequest||page!=='opportunities')return;
    analysisPage.innerHTML=analysisHeading('Возможности','Последние 28 полных дней против предыдущих 28. Анализ веб-поиска для всех доступных сайтов.')+`<div class="filter-row"><select id="opportunityKind" aria-label="Тип возможности"><option value="queries">Запросы: позиции 4–15</option><option value="pages">Страницы с падением</option></select><select id="opportunitySite" aria-label="Сайт возможностей"><option value="">Все сайты</option>${sites.filter(s=>s.active).map(s=>`<option value="${esc(s.id)}">${esc(domain(s.id))}</option>`).join('')}</select><input id="opportunitySearch" class="group-input compact-input" placeholder="Запрос, URL или группа…"><label>Показы от <input id="opportunityMin" type="number" min="1" value="100"></label><label>CTR до, % <input id="opportunityCtr" type="number" min="0" max="100" step="0.1" value="3"></label><label>Падение от, % <input id="opportunityDrop" type="number" min="0" max="100" value="20"></label><button class="button primary" id="scanOpportunities">Обновить анализ</button></div><p class="help">Порог показов и CTR можно менять. Для страниц: от 10 кликов в предыдущем периоде. Отсутствующая строка API не считается нулём. API скрывает часть запросов; анализ охватывает до 50 000 строк каждого отчёта.</p><div id="opportunityProgress" class="notice"></div><div id="opportunityTable" class="table-wrap"></div>`;
    $('backPortfolio').onclick=()=>navigate('portfolio');for(const id of ['opportunityKind','opportunitySite'])$(id).onchange=renderOpportunities;for(const id of ['opportunitySearch','opportunityMin','opportunityCtr','opportunityDrop'])$(id).oninput=renderOpportunities;
    $('scanOpportunities').onclick=async()=>{if(demo)return toast('В демо анализ вымышленный');try{const r=await api('/api/opportunities/scan',{});toast(r.started?'Анализ запущен в фоне':'Анализ уже выполняется');await pollOpportunities()}catch(e){toast(e.message)}};renderOpportunities();if(opportunityData.job.running)analysisTimer=setTimeout(pollOpportunities,2000);
  }catch(e){if(request===analysisRequest)analysisPage.innerHTML=analysisHeading('Возможности','')+'<p>'+esc(e.message)+'</p>';if($('backPortfolio'))$('backPortfolio').onclick=()=>navigate('portfolio')}
}
async function pollOpportunities(){if(page!=='opportunities')return;try{opportunityData=await api('/api/opportunities');if(page!=='opportunities')return;renderOpportunities();if(opportunityData.job.running)analysisTimer=setTimeout(pollOpportunities,2500)}catch(e){toast(e.message)}}
function renderOpportunities(){const kind=$('opportunityKind').value,query=$('opportunitySearch').value.toLowerCase();let rows=[];for(const site of opportunityData.sites){if($('opportunitySite').value&&site.site!==$('opportunitySite').value)continue;for(const row of (kind==='queries'?site.queries:site.pages)){if(query&&!(row.label+' '+site.site+' '+site.tag).toLowerCase().includes(query))continue;if(kind==='queries'&&(row.impressions<Number($('opportunityMin').value)||row.ctr*100>Number($('opportunityCtr').value)))continue;if(kind==='pages'&&row.drop<Number($('opportunityDrop').value))continue;rows.push({...row,site:site.site,updated:site.updated,start:site.start,end:site.end})}}rows.sort((a,b)=>kind==='queries'?b.impressions-a.impressions:b.loss-a.loss);const job=opportunityData.job;$('opportunityProgress').textContent=(job.running?`Анализ: ${job.done} / ${job.total}. `:'')+`Загружено сайтов: ${opportunityData.sites.length}; найдено: ${rows.length}.`+(job.errors?.length?' Ошибки: '+job.errors.length+'. '+job.errors[0].message:'');$('scanOpportunities').disabled=job.running;
  $('opportunityTable').innerHTML='<table><thead><tr><th>Сайт / '+(kind==='queries'?'Запрос':'Страница')+'</th>'+(kind==='queries'?'<th>Показы</th><th>Клики</th><th>CTR</th><th>Позиция</th>':'<th>Было кликов</th><th>Стало</th><th>Потеря</th><th>Падение</th>')+'<th>Период / загрузка</th></tr></thead><tbody>'+rows.slice(0,1000).map(r=>`<tr><td><button class="text-button" data-op-site="${esc(r.site)}">${esc(domain(r.site))}</button><div>${esc(r.label)}</div></td>${kind==='queries'?`<td>${fmt(r.impressions)}</td><td>${fmt(r.clicks)}</td><td>${pct(r.ctr)}</td><td>${dec(r.position)}</td>`:`<td>${fmt(r.before)}</td><td>${fmt(r.after)}</td><td>−${fmt(r.loss)}</td><td>−${dec(r.drop)}%</td>`}<td>${esc(r.start)} — ${esc(r.end)}<small>${nice(r.updated)}</small></td></tr>`).join('')+'</tbody></table>'+(!rows.length?'<div class="empty">Нет результатов. Запустите анализ или измените фильтры.</div>':'')+(rows.length>1000?'<p class="help">Показана первая 1000 строк. Уточните фильтры.</p>':'');$('opportunityTable').onclick=e=>{const b=e.target.closest('[data-op-site]');if(b)openDetail(b.dataset.opSite)};
}

// Clearly labelled demo data exercises each state without writing user reports.
const previousMakeDemo=makeDemo;
function demoSeries(bounds,seed=1){const ticks=chartTicks(bounds,[]);return ticks.map((key,i)=>{const impressions=Math.round((90+seed*7)*(1.1+Math.sin(i*.7+seed)*.45));const clicks=Math.round(impressions*(.02+Math.abs(Math.sin(i))*.03));return {keys:[key],clicks,impressions,ctr:clicks/impressions,position:5+seed%8+Math.sin(i*.4)}})}
makeDemo=function(){const output=previousMakeDemo();if(range.period==='24h')for(let i=0;i<output.length;i++){const rows=demoSeries({...range,...hourWindow()},i+1);output[i].report={rows,totals:total(rows),period:'24h',...hourWindow(),metadata:{first_incomplete_hour:rows.at(-2).keys[0]}}}return output};
function demoSiteReport(params){const series=demoSeries({...params,...(params.period==='24h'?hourWindow():{})},7);let table=Array.from({length:120},(_,i)=>{const impressions=1000-i*7,clicks=Math.round(impressions*.025);const label=params.dimension==='query'?'запрос '+(i+1):params.dimension==='page'?'https://'+domain(params.site)+'/page-'+(i+1):params.dimension==='country'?['ita','usa','rus'][i%3]:['DESKTOP','MOBILE','TABLET'][i%3];return {keys:[label],impressions,clicks,ctr:clicks/impressions,position:4+i/15}});if(['country','device'].includes(params.dimension))table=table.slice(0,3);if(params[params.dimension])table=table.filter(r=>r.keys[0].toLowerCase().includes(params[params.dimension].toLowerCase()));return {series,rows:table.slice(params.offset,params.offset+50),totals:total(series),has_more:table.length>params.offset+50,updated:new Date().toISOString(),metadata:{},period:params.period,...(params.period==='24h'?hourWindow():{})}}
function demoAlerts(){return {alerts:Object.entries(problemNames).map(([kind,title],i)=>({id:'demo-'+i,site:sites[i]?.id||'sc-domain:example.test',tag:sites[i]?.tag||'',kind,title,message:kind.includes('drop')?'Падение 42% относительно обычного уровня.':'Демонстрационный сигнал',severity:i%2?'warning':'critical',value:42,acknowledged:false})),insufficient:[],settings:{drop:30,min_clicks:20,min_impressions:100,position:3,stale_hours:36},start:shift(ptToday(),-23),end:shift(ptToday(),-3),total_sites:sites.length}}
function demoOpportunities(){return {sites:sites.slice(0,8).map((s,i)=>({site:s.id,tag:s.tag,updated:new Date().toISOString(),start:shift(ptToday(),-30),end:shift(ptToday(),-3),queries:[{label:'перспективный запрос '+(i+1),impressions:1200+i*70,clicks:12,ctr:.01,position:5+i}],pages:[{label:'https://'+domain(s.id)+'/guide',before:100+i*10,after:40,loss:60+i*10,drop:(1-40/(100+i*10))*100}]})),job:{running:false,done:8,total:8,errors:[]}}}
const oldLoadDashboard=loadDashboard;loadDashboard=async function(){await oldLoadDashboard();const finished=status.job?.finished;if(demo)return;if(finished!==previousSync||Date.now()-alertsRefreshAt>60000){previousSync=finished;alertsRefreshAt=Date.now();try{await getAlerts();if(page==='problems'&&$('problemTable'))renderProblems()}catch{}}};
setInterval(()=>{if(!demo&&page==='problems'&&status.job?.running&&$('analysisMessage'))$('analysisMessage').textContent=`Синхронизация: ${status.job.done} / ${status.job.total}`},2500);
render();route();

// Compact navigation and accessible icon menus.
const uiIcon=path=>`<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
const sortIcon=uiIcon('<path d="M8 4v16m-4-4 4 4 4-4M16 20V4m-4 4 4-4 4 4"/>');
function iconMenu(select,label,icons){
  const wrap=document.createElement('div');wrap.className='icon-menu';
  const trigger=document.createElement('button');trigger.type='button';trigger.className='icon-control';trigger.setAttribute('aria-label',label);trigger.setAttribute('aria-haspopup','menu');trigger.setAttribute('aria-expanded','false');
  const menu=document.createElement('div');menu.className='icon-menu-panel';menu.setAttribute('role','menu');menu.setAttribute('aria-label',label);menu.hidden=true;
  select.before(wrap);select.hidden=true;wrap.append(trigger,menu);
  function update(){trigger.innerHTML=icons[select.value]||sortIcon;trigger.title=label+': '+select.selectedOptions[0].textContent;menu.innerHTML='';for(const option of select.options){const item=document.createElement('button');item.type='button';item.setAttribute('role','menuitemradio');item.setAttribute('aria-checked',String(option.value===select.value));item.innerHTML=(icons[option.value]||'')+'<span>'+esc(option.textContent)+'</span><span class="menu-check">'+(option.value===select.value?'✓':'')+'</span>';item.onclick=()=>{select.value=option.value;select.onchange?.();update();close();trigger.focus()};menu.append(item)}}
  function close(){menu.hidden=true;trigger.setAttribute('aria-expanded','false')}
  trigger.onclick=()=>{const open=menu.hidden;closeIconMenus.forEach(fn=>fn());menu.hidden=!open;trigger.setAttribute('aria-expanded',String(open));if(open)menu.querySelector('[aria-checked="true"]')?.focus()};
  wrap.onkeydown=e=>{const items=[...menu.children],index=items.indexOf(document.activeElement);if(e.key==='Escape'){close();trigger.focus()}else if(!menu.hidden&&['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();items[e.key==='Home'?0:e.key==='End'?items.length-1:(index+(e.key==='ArrowDown'?1:-1)+items.length)%items.length].focus()}};
  document.addEventListener('click',e=>{if(!wrap.contains(e.target))close()});closeIconMenus.push(close);update();return wrap;
}
const closeIconMenus=[];
const sortingMenu=iconMenu($('sort'),'Сортировка',{});$('resultCount').after(sortingMenu);document.querySelector('.view-icon')?.remove();
const themeIcons={light:uiIcon('<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>'),dark:uiIcon('<path d="M20 15A9 9 0 0 1 9 4a9 9 0 1 0 11 11Z"/>'),anthracite:uiIcon('<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 1 0 18Z" fill="currentColor" stroke="none"/>')};
iconMenu(themePicker,'Тема',themeIcons);
const railBottom=document.querySelector('.rail-bottom');
for(const [button,id,label,icon] of [[problemsButton,'railProblems','Проблемы портфеля',uiIcon('<path d="m12 3 10 18H2Z"/><path d="M12 9v5m0 3v.1"/>')],[opportunitiesButton,'railOpportunities','Возможности',uiIcon('<path d="m3 17 6-6 4 4 8-11m-6 0h6v6"/>')]]){button.id=id;button.className='nav-icon';button.innerHTML=icon;button.title=label;button.setAttribute('aria-label',label);railBottom.before(button)}
function updateRail(){for(const [id,active] of [['home',page==='portfolio'&&!favorites],['railFav',page==='portfolio'&&favorites],['railProblems',page==='problems'],['railOpportunities',page==='opportunities']]){$(id).classList.toggle('active',active);if(active)$(id).setAttribute('aria-current','page');else $(id).removeAttribute('aria-current')}}
const beforeIconRender=render;render=function(){beforeIconRender();updateRail()};
const beforeIconRoute=route;route=function(){beforeIconRoute();updateRail()};window.addEventListener('hashchange',updateRail);
$('railFav').onclick=()=>{favorites=true;limit=30;navigate('portfolio');render()};
updateRail();
