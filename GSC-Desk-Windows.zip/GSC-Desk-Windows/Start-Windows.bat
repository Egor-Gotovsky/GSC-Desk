@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
    py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)" >nul 2>&1
    if not errorlevel 1 goto use_py
)
where python >nul 2>&1
if not errorlevel 1 (
    python -c "import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)" >nul 2>&1
    if not errorlevel 1 goto use_python
)
echo Python 3.9 or later was not found.
echo Install Python from https://www.python.org/downloads/windows/
echo During installation enable "Add Python to PATH".
pause
exit /b 1
:use_py
py -3 app.py
goto done
:use_python
python app.py
:done
echo.
echo GSC Desk has stopped. Press any key to close this window.
pause >nul
